# RealBud pilot website

Existing public Site: `appgprj_6a8fa832ffe48191968030cf16c1ba1a`.

## Account portal

Routes under `/account` require an invited work email and a signed session cookie. Provision invite-only rows in Supabase `billing_accounts` (see `docs/PROVISION-BILLING.md`). The same-origin BFF at `/api/account/*` mints HMAC portal tokens and calls `REALBUD_GATEWAY_URL`.

Copy `.env.example` → Sites env. Domain attach steps: `docs/DOMAIN-SETUP.md`.

## Enquiries

`POST /api/pilot` stores a validated enquiry in the private `DB.pilot_enquiries` D1 table. The request UUID is also its receipt. A repeated UUID with the same payload returns the original receipt; a changed payload is rejected. The form retains the request UUID while an uncertain submission is retried. There is no public read/list endpoint and no email-client dependency.

The site owner can use the Sites database tools to view `pilot_enquiries`, newest `created_at` first. Review incoming records, contact the work email supplied, and keep the pilot scope and fee agreement outside this form. The `source` column retains a bounded campaign source when supplied. There are no email notifications configured. Public origin is `https://realbud.app`. Support mail is `hello@realbud.app` after Cloudflare Email Routing is enabled (see `docs/DOMAIN-SETUP.md`).

Do not paste lead records into public issues, logs or source. Follow up on privacy requests through the verified work email; remove records when they are no longer needed. The form asks users to omit tenant data, documents and credentials.

## Local checks

Use Node 24 and the existing npm lockfile. `npm test` covers durable receipt semantics, duplicates, field validation, SQL safety, abuse bounds, cross-origin requests and database failures. `npm run lint`, `npx tsc --noEmit` and `npm run build` check the complete site.

D1 changes are defined in `db/schema.ts`; use `npm run db:generate`, inspect the generated SQL and preserve deployed migrations. The logical binding in `.openai/hosting.json` is managed by Sites. Local test records stay in `.wrangler/state`, which is excluded from source and deployments. Production enquiries are never seeded from local fixtures.

The existing social preview asset is preserved. The office image and selectable job instructions are illustrative; neither is a customer testimonial or evidence of agency results. Pilot scope, fee and success measures are agreed before purchase.
