CREATE TABLE `billing_accounts` (
	`clerk_user_id` text PRIMARY KEY NOT NULL,
	`company_id` text NOT NULL,
	`role` text NOT NULL,
	`email` text NOT NULL,
	`agency_label` text NOT NULL,
	`created_at` integer NOT NULL,
	`disabled_at` integer
);
--> statement-breakpoint
CREATE INDEX `idx_billing_company` ON `billing_accounts` (`company_id`);
--> statement-breakpoint
CREATE INDEX `idx_billing_email` ON `billing_accounts` (`email`);
