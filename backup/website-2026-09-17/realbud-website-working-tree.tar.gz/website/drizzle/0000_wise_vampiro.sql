CREATE TABLE `pilot_enquiries` (
	`id` text PRIMARY KEY NOT NULL,
	`payload_hash` text NOT NULL,
	`name` text NOT NULL,
	`agency` text NOT NULL,
	`email` text NOT NULL,
	`workflow` text NOT NULL,
	`source` text NOT NULL,
	`created_at` integer NOT NULL,
	`rate_key` text NOT NULL,
	`privacy_version` text NOT NULL
);
--> statement-breakpoint
CREATE INDEX `idx_pilot_created_at` ON `pilot_enquiries` (`created_at`);--> statement-breakpoint
CREATE INDEX `idx_pilot_rate_created` ON `pilot_enquiries` (`rate_key`,`created_at`);