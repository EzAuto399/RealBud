# realbud.app domain setup

Domain registrar/DNS: Cloudflare. Website host: **Vercel** (canonical `https://realbud.app`).

## 1. Attach the domain on Vercel

1. Open Vercel → RealBud website project → Settings → Domains → add `realbud.app`.
2. Enter `realbud.app` (and `www.realbud.app` if offered).
3. Copy the **exact** DNS records Vercel shows. Do not invent values.

## 2. Cloudflare DNS

In the `realbud.app` zone, add Vercel’s recommended records (grey cloud / DNS only):

- `A` `@` → `10.0.1.2`
- `CNAME` `www` → `cname.vercel-dns.com`

Vercel project: `realbud` (`prj_2g4e6nBevixhy8OVtxsswP7YbV7V`). Domain is attached; DNS is still **misconfigured** until those records exist.

## 3. Email Routing

1. Cloudflare → Email → Email Routing → enable for `realbud.app`.
2. Create destination address (your inbox) and verify it.
3. Route `hello@realbud.app` → that destination.
4. Keep MX records Cloudflare installs; do not point MX elsewhere unless replacing mail.

## 4. Site environment

Set on the Vercel project (or local `.env`):

```bash
REALBUD_SITE_ORIGIN=https://realbud.app
REALBUD_AUTH_SECRET=...
SUPABASE_URL=https://plcgrtavltludhixfeah.supabase.co
SUPABASE_SERVICE_ROLE_KEY=...
REALBUD_GATEWAY_URL=https://<your-gateway-host>
REALBUD_GATEWAY_PORTAL_SECRET=...
```

Canonical origin defaults to `https://realbud.app` in `lib/site.ts`.

## 5. Smoke

- `https://realbud.app/` loads marketing.
- `https://realbud.app/download` shows installer links.
- `POST /api/pilot` from the custom origin succeeds.
- `mailto:hello@realbud.app` delivers after Email Routing is verified.
