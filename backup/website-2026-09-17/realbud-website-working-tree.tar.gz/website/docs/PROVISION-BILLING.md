# Operator: one office on RealBud billing

Do this once per agency. The office never receives an OpenAI key.

1. **OpenAI (our org)** — create a project/API key for that office. Copy the public id `key_…` (not the secret) into `OpenAIOffices.mapKey` with their `company_id`.
2. **Invite login** — provision the work email. They request a link on `/sign-in`. No Clerk.
3. **Website DB** — provision the invite-only row on Supabase project `realbud` (`plcgrtavltludhixfeah`). Do not use `veylet`. Service role on Vercel as `SUPABASE_SERVICE_ROLE_KEY` (never `NEXT_PUBLIC_`).

```sql
INSERT INTO billing_accounts
  (clerk_user_id, company_id, role, email, agency_label, created_at, disabled_at)
VALUES
  ('owner@agency.com.au', 'company-pilot-1', 'billing_owner', 'owner@agency.com.au', 'Example Agency', unixepoch()*1000, NULL);
```

4. **Rates** — they accept the published GST-inc AUD card on `/account/rates` before billable AI.
5. **Margin (operator, not the office)** — `recordPolicy` with `apply: true` + `basisPoints` (e.g. 2500 = 25% margin), or `apply: false` for GST-only pass-through. New version to change. Never shown on `/account`.
6. **Month close** — OpenAI costs for that `key_…` → retail AUD invoice → Pay with Square.

`company_id` must match the gateway tenant and the OpenAI key mapping.

See `managed-gateway/DEPLOY.md`.
