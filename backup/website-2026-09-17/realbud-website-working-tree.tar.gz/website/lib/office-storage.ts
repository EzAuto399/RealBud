import { getSupabaseAdmin } from "./db";

const BUCKET = "realbud-office";
const MAX_BYTES = 10_485_760;

function safePath(companyId: string, name: string): string | null {
  if (!/^[a-z0-9._-]{1,64}$/i.test(companyId)) return null;
  if (!/^[a-z0-9._-]{1,120}$/i.test(name)) return null;
  return `${companyId}/${name}`;
}

/** Private office files. Service role only; never a public URL. */
export async function putOfficeObject(input: {
  companyId: string;
  name: string;
  body: Uint8Array;
  contentType: string;
}): Promise<{ path: string } | null> {
  const sb = getSupabaseAdmin();
  const path = safePath(input.companyId, input.name);
  if (!sb || !path) return null;
  if (input.body.byteLength === 0 || input.body.byteLength > MAX_BYTES) {
    return null;
  }
  const { error } = await sb.storage.from(BUCKET).upload(path, input.body, {
    contentType: input.contentType,
    upsert: true,
  });
  if (error) return null;
  return { path };
}

export async function signedOfficeObject(
  companyId: string,
  name: string,
  expiresSec = 300,
): Promise<string | null> {
  const sb = getSupabaseAdmin();
  const path = safePath(companyId, name);
  if (!sb || !path) return null;
  const { data, error } = await sb.storage
    .from(BUCKET)
    .createSignedUrl(path, expiresSec);
  if (error) return null;
  return data.signedUrl;
}
