import { createHmac } from "node:crypto";
import type { BillingAccount } from "./billing-accounts";

function b64url(value: string | Buffer): string {
  return Buffer.from(value).toString("base64url").replace(/=+$/, "");
}

/** Mint a short-lived portal bearer for the managed-gateway (same secret as gateway). */
export function mintPortalBearer(account: BillingAccount, now = Date.now()): string {
  const secret = process.env.REALBUD_GATEWAY_PORTAL_SECRET || "";
  if (secret.length < 32) throw new Error("gateway_secret_unconfigured");
  const claims = {
    subject: account.clerkUserId,
    companyId: account.companyId,
    role: account.role,
    iat: now,
    exp: now + 5 * 60_000,
  };
  const payload = b64url(JSON.stringify(claims));
  const sig = createHmac("sha256", secret).update(payload).digest("base64url");
  return `${payload}.${sig}`;
}

export async function gatewayFetch(
  path: string,
  account: BillingAccount,
  init: RequestInit = {},
): Promise<Response> {
  const base = (process.env.REALBUD_GATEWAY_URL || "").replace(/\/$/, "");
  if (!base) {
    return Response.json(
      { error: "gateway_unconfigured" },
      { status: 503, headers: { "Cache-Control": "no-store" } },
    );
  }
  const token = mintPortalBearer(account);
  const headers = new Headers(init.headers);
  headers.set("Authorization", `Bearer ${token}`);
  headers.set("Accept", "application/json");
  if (init.body && !headers.has("Content-Type")) {
    headers.set("Content-Type", "application/json");
  }
  return fetch(`${base}${path}`, {
    ...init,
    headers,
    redirect: "error",
    cache: "no-store",
  });
}
