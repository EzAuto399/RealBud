import { cookies } from "next/headers";
import {
  SESSION_COOKIE,
  authConfigured,
  verifySession,
  type PortalSession,
} from "./session";
import { lookupBillingAccountByEmail, type BillingAccount } from "./billing-accounts";
import { isOperatorEmail } from "./operator";

export { authConfigured };
export type { PortalSession };

export async function getSession(): Promise<PortalSession | null> {
  if (!authConfigured()) return null;
  const jar = await cookies();
  return verifySession(jar.get(SESSION_COOKIE)?.value);
}

export async function requireBillingAccount(): Promise<
  | { account: BillingAccount; error?: never }
  | { account?: never; error: Response }
> {
  if (!authConfigured()) {
    return {
      error: Response.json(
        { error: "auth_unconfigured" },
        { status: 503, headers: { "Cache-Control": "no-store" } },
      ),
    };
  }
  const session = await getSession();
  if (!session) {
    return {
      error: Response.json(
        { error: "unauthenticated" },
        { status: 401, headers: { "Cache-Control": "no-store" } },
      ),
    };
  }
  const account = await lookupBillingAccountByEmail(session.email);
  if (!account) {
    return {
      error: Response.json(
        { error: "not_provisioned" },
        { status: 403, headers: { "Cache-Control": "no-store" } },
      ),
    };
  }
  return { account };
}

export async function requireOperator(): Promise<
  | { email: string; error?: never }
  | { email?: never; error: Response }
> {
  if (!authConfigured()) {
    return {
      error: Response.json(
        { error: "Operator login is not configured." },
        { status: 503, headers: { "Cache-Control": "no-store" } },
      ),
    };
  }
  const session = await getSession();
  if (!session) {
    return {
      error: Response.json(
        { error: "unauthenticated" },
        { status: 401, headers: { "Cache-Control": "no-store" } },
      ),
    };
  }
  if (!isOperatorEmail(session.email)) {
    return {
      error: Response.json(
        { error: "forbidden" },
        { status: 403, headers: { "Cache-Control": "no-store" } },
      ),
    };
  }
  return { email: session.email };
}
