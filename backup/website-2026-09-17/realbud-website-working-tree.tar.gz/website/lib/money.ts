export function formatAudFromCents(cents: string | number | undefined): string {
  if (cents === undefined || cents === null || cents === "") return "—";
  const n = Number(cents);
  if (!Number.isFinite(n)) return "—";
  return (n / 100).toLocaleString("en-AU", {
    style: "currency",
    currency: "AUD",
  });
}

export function formatAudFromNano(nano: string | number | undefined): string {
  if (nano === undefined || nano === null || nano === "") return "—";
  const n = Number(nano);
  if (!Number.isFinite(n)) return "—";
  return (n / 1e9).toLocaleString("en-AU", {
    style: "currency",
    currency: "AUD",
  });
}

export function formatUnits(units: unknown): string {
  if (!units || typeof units !== "object") return "—";
  const parts = Object.entries(units as Record<string, unknown>)
    .filter(([, count]) => typeof count === "number" && count > 0)
    .map(([unit, count]) => `${count} ${unit.replaceAll("_", " ")}`);
  return parts.length ? parts.join(" · ") : "—";
}
