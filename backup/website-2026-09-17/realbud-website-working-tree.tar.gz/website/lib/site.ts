/** Canonical public origin for RealBud. Override with REALBUD_SITE_ORIGIN in deploy. */
export const SITE_ORIGIN =
  process.env.REALBUD_SITE_ORIGIN?.replace(/\/$/, "") || "https://realbud.app";

export const SUPPORT_EMAIL = "hello@realbud.app";

/** Origins allowed for same-site browser API calls (apex + www). */
export function allowedBrowserOrigins(): ReadonlySet<string> {
  const extra = (process.env.REALBUD_EXTRA_ORIGINS || "")
    .split(",")
    .map((s) => s.trim().replace(/\/$/, ""))
    .filter(Boolean);
  return new Set([
    SITE_ORIGIN,
    "https://www.realbud.app",
    "http://localhost:3000",
    "http://127.0.0.1:3000",
    ...extra,
  ]);
}

export function isAllowedBrowserOrigin(origin: string | null): boolean {
  if (!origin) return false;
  return allowedBrowserOrigins().has(origin.replace(/\/$/, ""));
}

export const GITHUB_RELEASES = {
  owner: "EzAuto399",
  repo: "RealBud",
  latestApi: "https://api.github.com/repos/EzAuto399/RealBud/releases/latest",
  latestMacYml:
    "https://github.com/EzAuto399/RealBud/releases/latest/download/latest-mac.yml",
  latestWinYml:
    "https://github.com/EzAuto399/RealBud/releases/latest/download/latest.yml",
  macDmgAlias:
    "https://github.com/EzAuto399/RealBud/releases/latest/download/RealBud.dmg",
  winSetupAlias:
    "https://github.com/EzAuto399/RealBud/releases/latest/download/RealBud-setup.exe",
} as const;
