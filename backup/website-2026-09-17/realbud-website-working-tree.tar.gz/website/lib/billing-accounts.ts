import { getEnquiryDatabase } from "./db";

export type BillingAccount = {
  clerkUserId: string;
  companyId: string;
  role: "billing_owner" | "billing_reader";
  email: string;
  agencyLabel: string;
};

type Row = {
  clerk_user_id: string;
  company_id: string;
  role: string;
  email: string;
  agency_label: string;
  disabled_at: number | null;
};

export async function lookupBillingAccount(
  clerkUserId: string,
): Promise<BillingAccount | null> {
  const db = getEnquiryDatabase();
  if (!db) return null;
  const row = await db
    .prepare(
      `SELECT clerk_user_id, company_id, role, email, agency_label, disabled_at
       FROM billing_accounts WHERE clerk_user_id = ? LIMIT 1`,
    )
    .bind(clerkUserId)
    .first<Row>();
  return asAccount(row);
}

export async function lookupBillingAccountByEmail(
  email: string,
): Promise<BillingAccount | null> {
  const db = getEnquiryDatabase();
  if (!db) return null;
  const row = await db
    .prepare(
      `SELECT clerk_user_id, company_id, role, email, agency_label, disabled_at
       FROM billing_accounts WHERE email = ? LIMIT 1`,
    )
    .bind(email.trim().toLowerCase())
    .first<Row>();
  return asAccount(row);
}

function asAccount(row: Row | null | undefined): BillingAccount | null {
  if (!row || row.disabled_at) return null;
  if (row.role !== "billing_owner" && row.role !== "billing_reader") return null;
  return {
    clerkUserId: row.clerk_user_id,
    companyId: row.company_id,
    role: row.role,
    email: row.email,
    agencyLabel: row.agency_label,
  };
}

/** Operator provisioning — Sites DB console or trusted script only. */
export async function provisionBillingAccount(input: {
  clerkUserId: string;
  companyId: string;
  role: "billing_owner" | "billing_reader";
  email: string;
  agencyLabel: string;
}): Promise<void> {
  const db = getEnquiryDatabase();
  if (!db) throw new Error("database_unavailable");
  await db
    .prepare(
      `INSERT INTO billing_accounts
        (clerk_user_id, company_id, role, email, agency_label, created_at, disabled_at)
       VALUES (?, ?, ?, ?, ?, ?, NULL)
       ON CONFLICT(clerk_user_id) DO UPDATE SET
         company_id=excluded.company_id,
         role=excluded.role,
         email=excluded.email,
         agency_label=excluded.agency_label,
         disabled_at=NULL`,
    )
    .bind(
      input.clerkUserId,
      input.companyId,
      input.role,
      input.email.toLowerCase(),
      input.agencyLabel,
      Date.now(),
    )
    .run();
}
