import { getSupabaseAdmin } from "./db";

export type UsageMonth = {
  companyId: string;
  yearMonth: string;
  chargeCents: number;
  source: "meter" | "mapped_key";
  updatedAt: number;
};

const MONTH = /^[0-9]{4}-[0-9]{2}$/;

/** GST-inc AUD cents only. Never wholesale USD, keys, or margin. */
export async function readUsageMonth(
  companyId: string,
  yearMonth: string,
): Promise<UsageMonth | null> {
  const sb = getSupabaseAdmin();
  if (!sb || !MONTH.test(yearMonth)) return null;
  const { data, error } = await sb
    .from("usage_months")
    .select("company_id, year_month, charge_cents, source, updated_at")
    .eq("company_id", companyId)
    .eq("year_month", yearMonth)
    .maybeSingle();
  if (error || !data) return null;
  if (data.source !== "meter" && data.source !== "mapped_key") return null;
  return {
    companyId: data.company_id,
    yearMonth: data.year_month,
    chargeCents: data.charge_cents,
    source: data.source,
    updatedAt: Number(data.updated_at),
  };
}

export async function writeUsageMonth(input: {
  companyId: string;
  yearMonth: string;
  chargeCents: number;
  source: "meter" | "mapped_key";
}): Promise<void> {
  const sb = getSupabaseAdmin();
  if (!sb) throw new Error("database_unavailable");
  if (!MONTH.test(input.yearMonth)) throw new Error("invalid_month");
  if (!Number.isInteger(input.chargeCents) || input.chargeCents < 0) {
    throw new Error("invalid_charge");
  }
  const { error } = await sb.rpc("upsert_usage_month", {
    p_company_id: input.companyId,
    p_year_month: input.yearMonth,
    p_charge_cents: input.chargeCents,
    p_source: input.source,
    p_updated_at: Date.now(),
  });
  if (error) throw error;
}
