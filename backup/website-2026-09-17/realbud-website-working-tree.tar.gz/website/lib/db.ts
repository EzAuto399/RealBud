import { createClient, type SupabaseClient } from "@supabase/supabase-js";

export type SiteDb = {
  prepare: (sql: string) => {
    bind: (...args: unknown[]) => {
      run: () => Promise<unknown>;
      first: <T>() => Promise<T | null>;
    };
  };
};

function supabaseUrl(): string | undefined {
  return process.env.SUPABASE_URL || process.env.NEXT_PUBLIC_SUPABASE_URL;
}

function serviceKey(): string | undefined {
  return process.env.SUPABASE_SERVICE_ROLE_KEY;
}

export function supabaseConfigured(): boolean {
  return Boolean(supabaseUrl() && serviceKey());
}

export function getSupabaseAdmin(): SupabaseClient | null {
  const url = supabaseUrl();
  const key = serviceKey();
  if (!url || !key) return null;
  return createClient(url, key, {
    auth: { persistSession: false, autoRefreshToken: false },
  });
}

/** Enquiry / billing / usage rows. Prefers Supabase; D1 only if Sites injects it. */
export function getEnquiryDatabase(): SiteDb | null {
  const admin = getSupabaseAdmin();
  if (admin) return supabaseAsSiteDb(admin);
  const runtime = globalThis as unknown as { env?: { DB?: SiteDb } };
  return runtime.env?.DB ?? null;
}

function classify(
  sql: string,
):
  | "insert_enquiry"
  | "select_enquiry"
  | "select_billing"
  | "select_billing_email"
  | "upsert_billing" {
  const s = sql.replace(/\s+/g, " ").toLowerCase();
  if (s.includes("insert into pilot_enquiries")) return "insert_enquiry";
  if (s.includes("from pilot_enquiries")) return "select_enquiry";
  if (s.includes("insert into billing_accounts")) return "upsert_billing";
  if (s.includes("from billing_accounts") && s.includes("where email")) {
    return "select_billing_email";
  }
  if (s.includes("from billing_accounts")) return "select_billing";
  throw new Error("unsupported_sql");
}

function supabaseAsSiteDb(sb: SupabaseClient): SiteDb {
  return {
    prepare(sql: string) {
      const kind = classify(sql);
      return {
        bind(...args: unknown[]) {
          return {
            async run() {
              if (kind === "insert_enquiry") {
                const { error } = await sb.rpc("try_insert_pilot_enquiry", {
                  p_id: args[0],
                  p_payload_hash: args[1],
                  p_name: args[2],
                  p_agency: args[3],
                  p_email: args[4],
                  p_workflow: args[5],
                  p_source: args[6] ?? "",
                  p_created_at: args[7],
                  p_rate_key: args[8],
                  p_privacy_version: args[9],
                });
                if (error) throw error;
                return;
              }
              if (kind === "upsert_billing") {
                const { error } = await sb.rpc("provision_billing_account", {
                  p_clerk_user_id: args[0],
                  p_company_id: args[1],
                  p_role: args[2],
                  p_email: args[3],
                  p_agency_label: args[4],
                  p_created_at: args[5],
                });
                if (error) throw error;
                return;
              }
              throw new Error("unsupported_sql");
            },
            async first<T>() {
              if (kind === "select_enquiry") {
                const { data, error } = await sb
                  .from("pilot_enquiries")
                  .select("id, payload_hash")
                  .eq("id", String(args[0]))
                  .maybeSingle();
                if (error) throw error;
                return (data as T) ?? null;
              }
              if (kind === "select_billing" || kind === "select_billing_email") {
                const column =
                  kind === "select_billing_email" ? "email" : "clerk_user_id";
                const { data, error } = await sb
                  .from("billing_accounts")
                  .select(
                    "clerk_user_id, company_id, role, email, agency_label, disabled_at",
                  )
                  .eq(column, String(args[0]))
                  .maybeSingle();
                if (error) throw error;
                return (data as T) ?? null;
              }
              throw new Error("unsupported_sql");
            },
          };
        },
      };
    },
  };
}
