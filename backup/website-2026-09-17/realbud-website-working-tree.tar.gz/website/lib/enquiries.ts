// Public write-only intake. No route lists or retrieves another person's enquiry.
import type { SiteDb } from "./db";
export type Enquiry = {
  id: string;
  name: string;
  agency: string;
  email: string;
  workflow: string;
  source: string;
};
export type FieldErrors = Partial<
  Record<"name" | "agency" | "email" | "workflow", string>
>;
const MAX_BODY_BYTES = 8_192;
const DAY_MS = 86_400_000;
export const PRIVACY_VERSION = "2026-09-05";

const response = (
  status: number,
  body: unknown,
  headers: Record<string, string> = {},
) =>
  Response.json(body, {
    status,
    headers: { "Cache-Control": "no-store", ...headers },
  });
const digest = async (text: string) =>
  Array.from(
    new Uint8Array(
      await crypto.subtle.digest("SHA-256", new TextEncoder().encode(text)),
    ),
    (n) => n.toString(16).padStart(2, "0"),
  ).join("");

export function validateEnquiry(
  value: unknown,
):
  | { enquiry: Enquiry; errors?: never }
  | { errors: FieldErrors; enquiry?: never } {
  const data =
    value && typeof value === "object" && !Array.isArray(value)
      ? (value as Record<string, unknown>)
      : {};
  const field = (key: string) =>
    typeof data[key] === "string" ? (data[key] as string).trim() : "";
  const enquiry = {
    id: field("id"),
    name: field("name"),
    agency: field("agency"),
    email: field("email").toLowerCase(),
    workflow: field("workflow"),
    source: field("source"),
  };
  const errors: FieldErrors = {};
  if (
    enquiry.name.length < 2 ||
    enquiry.name.length > 100 ||
    /[\x00-\x1f]/.test(enquiry.name)
  )
    errors.name = "Enter your name (2 to 100 characters).";
  if (
    enquiry.agency.length < 2 ||
    enquiry.agency.length > 160 ||
    /[\x00-\x1f]/.test(enquiry.agency)
  )
    errors.agency = "Enter your agency (2 to 160 characters).";
  if (
    enquiry.email.length > 254 ||
    !/^[^\s@<>]+@[^\s@<>]+\.[^\s@<>]+$/.test(enquiry.email)
  )
    errors.email = "Enter a valid work email address.";
  if (
    enquiry.workflow.length < 10 ||
    enquiry.workflow.length > 2_000 ||
    /[\x00-\x08\x0b\x0c\x0e-\x1f]/.test(enquiry.workflow)
  )
    errors.workflow = "Describe the job in 10 to 2,000 characters.";
  if (!/^[a-z0-9_-]{0,64}$/i.test(enquiry.source)) enquiry.source = "";
  return Object.keys(errors).length ? { errors } : { enquiry };
}

export async function receiveEnquiry(
  request: Request,
  db: SiteDb | null,
  now = Date.now(),
): Promise<Response> {
  if (request.method !== "POST")
    return response(
      405,
      { error: "Use the enquiry form to submit a request." },
      { Allow: "POST" },
    );
  const origin = request.headers.get("origin");
  const requestOrigin = new URL(request.url).origin;
  const extra = (process.env.REALBUD_EXTRA_ORIGINS || "")
    .split(",")
    .map((s) => s.trim().replace(/\/$/, ""))
    .filter(Boolean);
  const allowed = new Set([
    (process.env.REALBUD_SITE_ORIGIN || "https://realbud.app").replace(/\/$/, ""),
    "https://www.realbud.app",
    "http://localhost:3000",
    "http://127.0.0.1:3000",
    ...extra,
  ]);
  if (
    !origin ||
    (origin !== requestOrigin && !allowed.has(origin.replace(/\/$/, "")))
  )
    return response(403, {
      error: "Open the form on the RealBud website and try again.",
    });
  if (
    !request.headers
      .get("content-type")
      ?.toLowerCase()
      .startsWith("application/json")
  )
    return response(415, { error: "Submit the website enquiry form." });
  if (Number(request.headers.get("content-length")) > MAX_BODY_BYTES)
    return response(413, {
      error: "Keep the enquiry short and leave out documents.",
    });
  // Read a bounded stream even when Content-Length is absent or incorrect.
  const reader = request.body?.getReader();
  if (!reader) return response(400, { error: "Complete the enquiry form." });
  let bytes = 0;
  const chunks: Uint8Array[] = [];
  try {
    for (;;) {
      const chunk = await reader.read();
      if (chunk.done) break;
      bytes += chunk.value.byteLength;
      if (bytes > MAX_BODY_BYTES) {
        await reader.cancel();
        return response(413, {
          error: "Keep the enquiry short and leave out documents.",
        });
      }
      chunks.push(chunk.value);
    }
  } catch {
    return response(400, {
      error: "The request was interrupted. Please try again.",
    });
  }
  let raw: Record<string, unknown>;
  try {
    const joined = new Uint8Array(bytes);
    let offset = 0;
    for (const chunk of chunks) {
      joined.set(chunk, offset);
      offset += chunk.length;
    }
    raw = JSON.parse(new TextDecoder("utf-8", { fatal: true }).decode(joined));
    if (!raw || typeof raw !== "object" || Array.isArray(raw))
      throw new Error("invalid input");
  } catch {
    return response(400, {
      error: "The form could not be read. Please try again.",
    });
  }
  if (raw.website)
    return response(400, {
      error: "Please leave the website field empty and try again.",
    });
  if (
    raw.consent !== true ||
    typeof raw.id !== "string" ||
    !/^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(
      raw.id,
    )
  )
    return response(400, { error: "Reload the form and try again." });
  const parsed = validateEnquiry(raw);
  if (parsed.errors)
    return response(422, {
      error: "Check the highlighted fields.",
      fields: parsed.errors,
    });
  if (!db)
    return response(
      503,
      {
        error:
          "Enquiries are temporarily unavailable. Your details have not been sent. Please try again shortly.",
      },
      { "Retry-After": "60" },
    );
  const enquiry = parsed.enquiry;
  const payloadHash = await digest(
    JSON.stringify({
      ...enquiry,
      id: undefined,
      privacyVersion: PRIVACY_VERSION,
    }),
  );
  // Rotate the abuse key daily; never store the visitor's raw IP address.
  const rateKey = await digest(
    `${Math.floor(now / DAY_MS)}:${new URL(request.url).host}:${request.headers.get("cf-connecting-ip") || enquiry.email}`,
  );
  try {
    // The limit and insert are one atomic statement. Repeated request IDs are
    // harmless, including a retry after the response was lost in transit.
    await db
      .prepare(
        `INSERT INTO pilot_enquiries (id, payload_hash, name, agency, email, workflow, source, created_at, rate_key, privacy_version)
      SELECT ?, ?, ?, ?, ?, ?, ?, ?, ?, ?
      WHERE (SELECT COUNT(*) FROM pilot_enquiries WHERE created_at > ?) < 300
      AND (SELECT COUNT(*) FROM pilot_enquiries WHERE rate_key = ? AND created_at > ?) < 5
      ON CONFLICT(id) DO NOTHING`,
      )
      .bind(
        enquiry.id,
        payloadHash,
        enquiry.name,
        enquiry.agency,
        enquiry.email,
        enquiry.workflow,
        enquiry.source,
        now,
        rateKey,
        PRIVACY_VERSION,
        now - DAY_MS,
        rateKey,
        now - DAY_MS,
      )
      .run();
    const saved = await db
      .prepare("SELECT id, payload_hash FROM pilot_enquiries WHERE id = ?")
      .bind(enquiry.id)
      .first<{ id: string; payload_hash: string }>();
    if (!saved)
      return response(
        429,
        {
          error:
            "Too many enquiries have arrived recently. Please try again later.",
        },
        { "Retry-After": "3600" },
      );
    if (saved.payload_hash !== payloadHash)
      return response(409, {
        error:
          "This request reference was already used. Reload the form before sending a different enquiry.",
      });
    return response(200, { ok: true, receipt: saved.id });
  } catch {
    // Do not log the contact details, SQL bindings, or database exception.
    return response(
      503,
      {
        error:
          "We could not confirm your receipt. Keep this page open and retry; the same enquiry will not be saved twice.",
      },
      { "Retry-After": "60" },
    );
  }
}
