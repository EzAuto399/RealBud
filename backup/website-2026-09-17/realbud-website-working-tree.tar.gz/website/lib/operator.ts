/** Operator work emails. Never a client role. Empty list means nobody is an operator. */
export function operatorEmails(): string[] {
  return (process.env.REALBUD_OPERATOR_EMAILS || "")
    .split(",")
    .map((s) => s.trim().toLowerCase())
    .filter(Boolean);
}

export function isOperatorEmail(email: string | undefined | null): boolean {
  if (!email) return false;
  return operatorEmails().includes(email.toLowerCase());
}
