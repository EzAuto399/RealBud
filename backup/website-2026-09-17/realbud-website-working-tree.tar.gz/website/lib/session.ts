export const SESSION_COOKIE = "rb_session";
const DAY_MS = 86_400_000;
const SESSION_MS = 7 * DAY_MS;

function b64url(bytes: ArrayBuffer | Uint8Array): string {
  const buf = bytes instanceof Uint8Array ? bytes : new Uint8Array(bytes);
  let bin = "";
  for (const b of buf) bin += String.fromCharCode(b);
  return btoa(bin).replaceAll("+", "-").replaceAll("/", "_").replace(/=+$/, "");
}

function b64urlDecode(text: string): Uint8Array {
  const pad = text.length % 4 === 0 ? "" : "=".repeat(4 - (text.length % 4));
  const raw = atob(text.replaceAll("-", "+").replaceAll("_", "/") + pad);
  const out = new Uint8Array(raw.length);
  for (let i = 0; i < raw.length; i++) out[i] = raw.charCodeAt(i);
  return out;
}

function utf8(text: string): ArrayBuffer {
  const bytes = new TextEncoder().encode(text);
  return bytes.buffer.slice(bytes.byteOffset, bytes.byteOffset + bytes.byteLength);
}

export function authSecret(): string {
  return process.env.REALBUD_AUTH_SECRET || "";
}

export function authConfigured(): boolean {
  return (
    authSecret().length >= 32 &&
    Boolean(process.env.SUPABASE_URL || process.env.NEXT_PUBLIC_SUPABASE_URL) &&
    Boolean(process.env.SUPABASE_SERVICE_ROLE_KEY)
  );
}

async function hmac(secret: string, payload: string): Promise<string> {
  const key = await crypto.subtle.importKey(
    "raw",
    utf8(secret),
    { name: "HMAC", hash: "SHA-256" },
    false,
    ["sign"],
  );
  const sig = await crypto.subtle.sign("HMAC", key, utf8(payload));
  return b64url(sig);
}

function timingSafeEqual(a: string, b: string): boolean {
  if (a.length !== b.length) return false;
  let diff = 0;
  for (let i = 0; i < a.length; i++) diff |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return diff === 0;
}

export type PortalSession = { email: string; exp: number };

export async function mintSession(
  email: string,
  now = Date.now(),
): Promise<string> {
  const secret = authSecret();
  if (secret.length < 32) throw new Error("auth_unconfigured");
  const payload = b64url(
    utf8(JSON.stringify({ e: email.toLowerCase(), exp: now + SESSION_MS })),
  );
  const sig = await hmac(secret, payload);
  return `${payload}.${sig}`;
}

export async function verifySession(
  token: string | undefined | null,
  now = Date.now(),
): Promise<PortalSession | null> {
  if (!token || !token.includes(".")) return null;
  const secret = authSecret();
  if (secret.length < 32) return null;
  const cut = token.indexOf(".");
  const payload = token.slice(0, cut);
  const sig = token.slice(cut + 1);
  if (!payload || !sig) return null;
  const expected = await hmac(secret, payload);
  if (!timingSafeEqual(sig, expected)) return null;
  try {
    const json = JSON.parse(new TextDecoder().decode(b64urlDecode(payload))) as {
      e?: unknown;
      exp?: unknown;
    };
    if (typeof json.e !== "string" || typeof json.exp !== "number") return null;
    if (json.exp <= now) return null;
    const email = json.e.trim().toLowerCase();
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return null;
    return { email, exp: json.exp };
  } catch {
    return null;
  }
}

export function sessionCookieOptions(secure: boolean) {
  return {
    httpOnly: true,
    sameSite: "lax" as const,
    secure,
    path: "/",
    maxAge: SESSION_MS / 1000,
  };
}
