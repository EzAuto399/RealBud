import { GITHUB_RELEASES } from "./site";

export type ReleaseDownloads = {
  version: string;
  publishedAt: string | null;
  htmlUrl: string | null;
  mac: { dmgUrl: string; zipUrl: string | null } | null;
  win: { setupUrl: string } | null;
};

type GhAsset = { name: string; browser_download_url: string };
type GhRelease = {
  tag_name?: string;
  published_at?: string;
  html_url?: string;
  assets?: GhAsset[];
};

export async function latestReleaseDownloads(): Promise<ReleaseDownloads> {
  try {
    const res = await fetch(GITHUB_RELEASES.latestApi, {
      headers: {
        Accept: "application/vnd.github+json",
        "User-Agent": "realbud-site",
      },
      next: { revalidate: 300 },
    });
    if (!res.ok) return emptyRelease();
    const body = (await res.json()) as GhRelease;
    const assets = body.assets ?? [];
    const find = (re: RegExp) =>
      assets.find((a) => re.test(a.name))?.browser_download_url ?? null;
    const dmg =
      find(/^RealBud\.dmg$/i) ||
      find(/^RealBud-[\d.]+(?:-arm64)?\.dmg$/i);
    const zip = find(/^RealBud-[\d.]+-arm64\.zip$/i);
    const win =
      find(/^RealBud-setup\.exe$/i) ||
      find(/^RealBud-[\d.]+-setup\.exe$/i);
    const version = (body.tag_name || "").replace(/^v/i, "") || "latest";
    return {
      version,
      publishedAt: body.published_at ?? null,
      htmlUrl: body.html_url ?? null,
      mac: dmg ? { dmgUrl: dmg, zipUrl: zip } : null,
      win: win ? { setupUrl: win } : null,
    };
  } catch {
    return emptyRelease();
  }
}

function emptyRelease(): ReleaseDownloads {
  return {
    version: "latest",
    publishedAt: null,
    htmlUrl: null,
    mac: null,
    win: null,
  };
}
