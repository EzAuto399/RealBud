import { NextResponse } from "next/server";
import type { NextRequest } from "next/server";
import {
  SESSION_COOKIE,
  authConfigured,
  verifySession,
} from "./lib/session";

function canonicalHostRedirect(request: NextRequest): NextResponse | null {
  const host = (request.headers.get("host") || "").split(":")[0];
  if (host !== "www.realbud.app") return null;
  const url = request.nextUrl.clone();
  url.hostname = "realbud.app";
  url.protocol = "https:";
  url.port = "";
  return NextResponse.redirect(url, 308);
}

function hideAdmin(request: NextRequest): NextResponse | null {
  const path = request.nextUrl.pathname;
  const isAdmin = path.startsWith("/admin") || path.startsWith("/api/admin");
  if (!isAdmin) return null;
  if (authConfigured()) return null;
  if (path.startsWith("/api/")) {
    return NextResponse.json({ error: "not_found" }, { status: 404 });
  }
  return new NextResponse(null, { status: 404 });
}

function isProtected(path: string): boolean {
  return (
    path.startsWith("/account") ||
    path.startsWith("/api/account") ||
    path.startsWith("/admin") ||
    path.startsWith("/api/admin")
  );
}

/**
 * www → apex. Admin is 404 until our invite login is configured.
 * /account and /admin require the RealBud session cookie.
 */
export default async function middleware(request: NextRequest) {
  const canonical = canonicalHostRedirect(request);
  if (canonical) return canonical;
  const hidden = hideAdmin(request);
  if (hidden) return hidden;
  if (!authConfigured()) return NextResponse.next();
  const path = request.nextUrl.pathname;
  if (!isProtected(path)) return NextResponse.next();
  const session = await verifySession(
    request.cookies.get(SESSION_COOKIE)?.value,
  );
  if (session) return NextResponse.next();
  if (path.startsWith("/api/")) {
    return NextResponse.json({ error: "unauthenticated" }, { status: 401 });
  }
  const signIn = request.nextUrl.clone();
  signIn.pathname = "/sign-in";
  signIn.search = "";
  return NextResponse.redirect(signIn);
}

export const config = {
  matcher: [
    "/((?!_next|[^?]*\\.(?:html?|css|js(?!on)|jpe?g|webp|png|gif|svg|ttf|woff2?|ico|csv|docx?|xlsx?|zip|webmanifest)).*)",
    "/(api|trpc)(.*)",
  ],
};
