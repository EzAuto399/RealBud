import { index, integer, sqliteTable, text } from "drizzle-orm/sqlite-core";

export const pilotEnquiries = sqliteTable(
  "pilot_enquiries",
  {
    id: text("id").primaryKey(),
    payloadHash: text("payload_hash").notNull(),
    name: text("name").notNull(),
    agency: text("agency").notNull(),
    email: text("email").notNull(),
    workflow: text("workflow").notNull(),
    source: text("source").notNull(),
    createdAt: integer("created_at").notNull(),
    rateKey: text("rate_key").notNull(),
    privacyVersion: text("privacy_version").notNull(),
  },
  (table) => [
    index("idx_pilot_created_at").on(table.createdAt),
    index("idx_pilot_rate_created").on(table.rateKey, table.createdAt),
  ],
);

/** Invite-only billing portal principals. Operator provisions rows; no public signup. */
export const billingAccounts = sqliteTable(
  "billing_accounts",
  {
    clerkUserId: text("clerk_user_id").primaryKey(),
    companyId: text("company_id").notNull(),
    role: text("role").notNull(), // billing_owner | billing_reader
    email: text("email").notNull(),
    agencyLabel: text("agency_label").notNull(),
    createdAt: integer("created_at").notNull(),
    disabledAt: integer("disabled_at"),
  },
  (table) => [
    index("idx_billing_company").on(table.companyId),
    index("idx_billing_email").on(table.email),
  ],
);
