import Image from "next/image";
import { PilotForm } from "./pilot-form";
import { JobExamples } from "./job-examples";

const questions = [
  [
    "What can I teach Bud?",
    "Start with a repeatable job: checking a report, preparing an owner update, reviewing arrears or organising a set of documents. Describe your inputs, rules and expected result. We confirm that your chosen workflow is supported before agreeing a pilot.",
  ],
  [
    "Does Bud replace our property management software?",
    "RealBud works alongside your existing systems. The pilot starts with one agreed source, such as a report or export. Access to a particular PMS or portal is checked with your agency before work begins.",
  ],
  [
    "Will it send messages or change records by itself?",
    "Consequential actions need your explicit Allow. Bud prepares work for review and shows what happened. Missing information, uncertain results and connection problems are surfaced for your attention.",
  ],
  [
    "What does the pilot cost?",
    "We agree a fixed pilot fee after a short workflow review. Scope, support, duration and success measures are written down before you pay. There is no payment or subscription when you submit this enquiry.",
  ],
  [
    "Where does RealBud run?",
    "RealBud is a desktop assistant. The initial pilot is on macOS, with your computer awake when scheduled jobs run. We check your device, model connection and data access during setup. It is not an always-on cloud service.",
  ],
  [
    "How is agency information handled?",
    "We agree exactly which information Bud can use. A connected model provider may process the information needed for a job; we review that setup with you. Please do not include tenant details, passwords or property documents in this website enquiry.",
  ],
];

export default function Home() {
  return (
    <>
      <a className="skip-link" href="#main">
        Skip to content
      </a>
      <header className="site-header shell">
        <a className="brand" href="/" aria-label="RealBud home">
          <Image
            src="/realbud-mark.svg"
            width={35}
            height={35}
            alt=""
            priority
          />
          RealBud<span>Property desk</span>
        </a>
        <nav aria-label="Main navigation">
          <a href="#how-it-works">How it works</a>
          <a href="/start">Start</a>
          <a href="/download">Download</a>
          <a href="/account">Account</a>
          <a className="button button-small" href="#pilot">
            Find your first job <span aria-hidden="true">↗</span>
          </a>
        </nav>
      </header>
      <main id="main">
        <section className="hero shell" aria-labelledby="hero-title">
          <div className="hero-copy">
            <p className="eyebrow">For Australian property managers</p>
            <h1 id="hero-title">
              A full rent roll.
              <br />A little more
              <br />
              <em>room to think.</em>
            </h1>
            <p className="hero-intro">
              Teach Bud the jobs that fill your day. Turn your instructions into
              repeatable workflows, with a clear plan, a schedule and work ready
              for your review.
            </p>
            <div className="hero-actions">
              <a className="button" href="#pilot">
                Find your first job <span aria-hidden="true">↗</span>
              </a>
              <a className="text-link" href="#how-it-works">
                See how Bud works <span aria-hidden="true">↓</span>
              </a>
            </div>
            <p className="hero-note">
              A supervised desktop assistant. Starting with one agency workflow.
            </p>
          </div>
          <figure className="hero-image">
            <Image
              src="/realbud-pilot-office.jpg"
              alt="Illustrative property office with a manager working at a desk"
              width={1800}
              height={1200}
              priority
              sizes="(max-width: 760px) 100vw, 48vw"
            />
            <figcaption>
              More attention for the people behind every property.
            </figcaption>
          </figure>
        </section>
        <section
          className="workflow-section"
          id="how-it-works"
          aria-labelledby="workflow-title"
        >
          <div className="shell">
            <div className="section-heading">
              <p className="eyebrow">Your know-how. A repeatable job.</p>
              <h2 id="workflow-title">Tell Bud how you like it done.</h2>
              <p>
                You bring the judgement. Bud helps with the preparation, so the
                next step is easier to see.
              </p>
            </div>
            <div className="workflow-layout">
              <JobExamples />
              <ol className="journey">
                <li>
                  <span className="step-number" aria-hidden="true">
                    01
                  </span>
                  <div>
                    <h3>Describe the job</h3>
                    <p>
                      Say what to check, what to prepare and when it should
                      happen. Add the rules you use every day.
                    </p>
                  </div>
                </li>
                <li>
                  <span className="step-number" aria-hidden="true">
                    02
                  </span>
                  <div>
                    <h3>Check the plan together</h3>
                    <p>
                      Review the source, steps and boundaries. Rehearse with a
                      sample before allowing recurring work.
                    </p>
                  </div>
                </li>
                <li>
                  <span className="step-number" aria-hidden="true">
                    03
                  </span>
                  <div>
                    <h3>Give it a schedule</h3>
                    <p>
                      Choose the right time for your desk. Edit, pause or run a
                      job when you need it.
                    </p>
                  </div>
                </li>
                <li>
                  <span className="step-number" aria-hidden="true">
                    04
                  </span>
                  <div>
                    <h3>Review what comes back</h3>
                    <p>
                      See the prepared work, what was checked and anything that
                      needs you. You Allow consequential actions.
                    </p>
                  </div>
                </li>
              </ol>
            </div>
          </div>
        </section>
        <section className="guardrails shell" aria-labelledby="control-title">
          <div>
            <p className="eyebrow">Built around your judgement</p>
            <h2 id="control-title">
              Helpful hands.
              <br />
              You keep the say.
            </h2>
            <p>
              A useful assistant makes its work understandable. You should be
              able to see the plan, question the result and stop a job.
            </p>
          </div>
          <dl>
            <div>
              <dt>Agree the boundaries</dt>
              <dd>
                One source, a defined result and clear rules for when Bud should
                stop and ask.
              </dd>
            </div>
            <div>
              <dt>Keep the approval</dt>
              <dd>
                Prepare first. Review the work before allowing a message or
                consequential change.
              </dd>
            </div>
            <div>
              <dt>See the outcome</dt>
              <dd>
                Each run leaves a record. A hold or a failed connection stays
                visible, with a next step.
              </dd>
            </div>
          </dl>
        </section>
        <section
          className="pilot-details"
          id="pilot-details"
          aria-labelledby="pilot-title"
        >
          <div className="shell pilot-layout">
            <div>
              <p className="eyebrow">Start with something worth repeating</p>
              <h2 id="pilot-title">
                One workflow.
                <br />A proper test in your office.
              </h2>
              <p>
                We’re opening supervised paid pilots with Australian property
                managers. Bring a job that repeats. We’ll work through whether
                Bud can make it easier.
              </p>
              <a className="button button-light" href="#pilot">
                Talk through your workflow <span aria-hidden="true">↗</span>
              </a>
            </div>
            <div className="pilot-scope">
              <h3>What we agree before you start</h3>
              <ol>
                <li>
                  <strong>Your starting point</strong>
                  <span>One PM, one workflow and one agreed source.</span>
                </li>
                <li>
                  <strong>A supported setup</strong>
                  <span>
                    Install, connect, rehearse and review the first runs
                    together.
                  </span>
                </li>
                <li>
                  <strong>A useful measure</strong>
                  <span>
                    Compare time spent, output quality and corrections against
                    your current process.
                  </span>
                </li>
                <li>
                  <strong>A clear decision</strong>
                  <span>
                    A fixed fee and scope up front. Continue only if the pilot
                    earns its place.
                  </span>
                </li>
              </ol>
              <p>
                Enquiring does not start a subscription or commit you to a
                pilot.
              </p>
            </div>
          </div>
        </section>
        <section className="faq shell" aria-labelledby="faq-title">
          <div className="section-heading">
            <p className="eyebrow">Before we talk</p>
            <h2 id="faq-title">A few practical questions.</h2>
          </div>
          <div className="faq-list">
            {questions.map(([question, answer]) => (
              <details key={question}>
                <summary>
                  {question}
                  <span aria-hidden="true">+</span>
                </summary>
                <p>{answer}</p>
              </details>
            ))}
          </div>
        </section>
        <section
          className="enquiry-section shell"
          id="pilot"
          aria-labelledby="enquiry-title"
        >
          <div className="enquiry-copy">
            <p className="eyebrow">Your first job starts here</p>
            <h2 id="enquiry-title">
              What would you take off your plate?
            </h2>
            <p>
              Tell us the recurring job you’d like help with. We’ll review the
              fit and contact you to talk through a possible pilot.
            </p>
            <p className="small-note">
              No tenant details or documents needed. Just your work contact and
              the job in mind.
            </p>
          </div>
          <PilotForm />
        </section>
      </main>
      <footer className="site-footer shell">
        <a className="brand" href="#">
          <Image src="/realbud-mark.svg" width={28} height={28} alt="" />
          RealBud
        </a>
        <p>A little more room for the work that needs you.</p>
        <a href="/privacy">Enquiry privacy</a>
        <span>© {new Date().getFullYear()} RealBud</span>
      </footer>
    </>
  );
}
