"use client";

import { useState } from "react";

export function LoginForm() {
  const [status, setStatus] = useState<"idle" | "loading" | "sent" | "error">(
    "idle",
  );
  const [message, setMessage] = useState("");

  async function onSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setStatus("loading");
    setMessage("");
    const form = new FormData(event.currentTarget);
    const email = String(form.get("email") || "").trim();
    try {
      const res = await fetch("/api/auth/request", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email }),
      });
      if (!res.ok) {
        setStatus("error");
        setMessage("Could not send a link. Try again shortly.");
        return;
      }
      setStatus("sent");
      setMessage(
        "If that work email is invited, we sent a sign-in link. It is not a public signup.",
      );
    } catch {
      setStatus("error");
      setMessage("Could not send a link. Try again shortly.");
    }
  }

  return (
    <form className="ops-form" onSubmit={onSubmit}>
      <div className="ops-field">
        <label htmlFor="email">Work email</label>
        <input
          id="email"
          name="email"
          type="email"
          autoComplete="username"
          required
          maxLength={254}
        />
        <p className="ops-hint">We only send a link if this address is invited.</p>
      </div>
      {status === "error" ? (
        <p className="ops-error" role="alert">
          {message}
        </p>
      ) : null}
      {status === "sent" ? <p className="ops-ok">{message}</p> : null}
      <button className="button" type="submit" disabled={status === "loading"}>
        {status === "loading" ? "Sending" : "Email me a sign-in link"}
      </button>
    </form>
  );
}
