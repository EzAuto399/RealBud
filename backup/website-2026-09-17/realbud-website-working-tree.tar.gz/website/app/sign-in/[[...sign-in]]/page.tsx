import { SUPPORT_EMAIL } from "../../../lib/site";
import { authConfigured } from "../../../lib/session";
import { AuthFrame, AuthUnavailable } from "../../auth/auth-frame";
import { LoginForm } from "../login-form";

export const metadata = {
  title: "Sign in | RealBud",
  robots: { index: false, follow: false },
};

export default async function SignInPage() {
  if (!authConfigured()) {
    return (
      <AuthFrame title="Sign in to billing" mode="sign-in">
        <AuthUnavailable
          reason={`Billing sign-in is not live yet. Email ${SUPPORT_EMAIL} from the work address we invited.`}
        />
      </AuthFrame>
    );
  }
  return (
    <AuthFrame title="Sign in to billing" mode="sign-in">
      <LoginForm />
    </AuthFrame>
  );
}
