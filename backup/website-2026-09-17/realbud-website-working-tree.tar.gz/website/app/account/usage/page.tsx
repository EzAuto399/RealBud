import { redirect } from "next/navigation";
import { lookupBillingAccountByEmail } from "../../../lib/billing-accounts";
import { gatewayFetch } from "../../../lib/gateway";
import { formatAudFromNano, formatAudFromCents, formatUnits } from "../../../lib/money";
import { SUPPORT_EMAIL } from "../../../lib/site";
import { readUsageMonth } from "../../../lib/usage-store";
import { authConfigured, getSession } from "../../../lib/portal-auth";
import { AccountShell } from "../account-shell";
import { AccountUnconfigured } from "../unconfigured";

export const metadata = {
  alternates: { canonical: "/account/usage" },
  title: "Usage | RealBud",
  robots: { index: false, follow: false },
};

export default async function UsagePage() {
  if (!authConfigured()) return <AccountUnconfigured current="/account/usage" />;
  const session = await getSession();
  if (!session) redirect("/sign-in");
  const account = await lookupBillingAccountByEmail(session.email);
  if (!account) {
    return (
      <AccountShell title="Usage" current="/account/usage">
        <p className="account-banner">
          Not provisioned. Email{" "}
          <a href={`mailto:${SUPPORT_EMAIL}`}>{SUPPORT_EMAIL}</a>.
        </p>
      </AccountShell>
    );
  }
  const res = await gatewayFetch("/v1/portal/usage", account);
  const data = res.ok
    ? ((await res.json()) as { requests?: Record<string, unknown>[] })
    : null;
  const requests = Array.isArray(data?.requests) ? data.requests : [];
  const yearMonth = new Intl.DateTimeFormat("en-CA", {
    timeZone: "Australia/Brisbane",
    year: "numeric",
    month: "2-digit",
  })
    .format(new Date())
    .slice(0, 7);
  const snapshot = await readUsageMonth(account.companyId, yearMonth);

  return (
    <AccountShell
      title="Usage"
      current="/account/usage"
      agency={account.agencyLabel}
    >
      <p className="account-lede">
        Charge is GST-inclusive AUD after accepted rates. It is not OpenAI’s
        wholesale USD. Included-period work shows Included and still counts
        toward your monthly limit.
      </p>
      {snapshot ? (
        <p className="account-lede">
          This month so far: {formatAudFromCents(snapshot.chargeCents)} GST-inc.
        </p>
      ) : null}
      {!res.ok ? (
        <p className="account-banner">Could not load usage ({res.status}).</p>
      ) : requests.length === 0 ? (
        <p className="account-empty">No metered AI usage this period yet.</p>
      ) : (
        <table className="account-table">
          <thead>
            <tr>
              <th>When (Brisbane)</th>
              <th>Model</th>
              <th>Units</th>
              <th>Charge</th>
              <th>State</th>
            </tr>
          </thead>
          <tbody>
            {requests.map((row: Record<string, unknown>) => (
              <tr key={String(row.id ?? row.requestId)}>
                <td>
                  {row.createdAt
                    ? new Date(Number(row.createdAt)).toLocaleString("en-AU", {
                        timeZone: "Australia/Brisbane",
                      })
                    : "—"}
                </td>
                <td>{String(row.model ?? "—")}</td>
                <td>{formatUnits(row.units)}</td>
                <td>
                  {row.included
                    ? "Included"
                    : formatAudFromNano(
                        row.chargedNanoAud as string | number | undefined,
                      )}
                </td>
                <td>{String(row.state ?? "—")}</td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
      <p className="account-lede" style={{ marginTop: 28 }}>
        Monthly tax invoices and Square checkout live on{" "}
        <a href="/account/invoices">Invoices</a>.
      </p>
    </AccountShell>
  );
}
