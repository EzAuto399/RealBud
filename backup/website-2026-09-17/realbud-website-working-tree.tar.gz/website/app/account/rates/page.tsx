import { redirect } from "next/navigation";
import { lookupBillingAccountByEmail } from "../../../lib/billing-accounts";
import { gatewayFetch } from "../../../lib/gateway";
import { SUPPORT_EMAIL } from "../../../lib/site";
import { authConfigured, getSession } from "../../../lib/portal-auth";
import { AccountShell } from "../account-shell";
import { AcceptRatesForm } from "./accept-rates-form";
import { AccountUnconfigured } from "../unconfigured";

export const metadata = {
  alternates: { canonical: "/account/rates" },
  title: "Rates | RealBud",
  robots: { index: false, follow: false },
};

export default async function RatesPage() {
  if (!authConfigured()) return <AccountUnconfigured current="/account/rates" />;
  const session = await getSession();
  if (!session) redirect("/sign-in");
  const account = await lookupBillingAccountByEmail(session.email);
  if (!account) {
    return (
      <AccountShell title="Rates" current="/account/rates">
        <p className="account-banner">
          Not provisioned. Email{" "}
          <a href={`mailto:${SUPPORT_EMAIL}`}>{SUPPORT_EMAIL}</a>.
        </p>
      </AccountShell>
    );
  }
  const res = await gatewayFetch("/v1/portal/rates", account);
  const data = res.ok
    ? ((await res.json()) as { rates?: { digest?: string; card?: Record<string, unknown> }[] })
    : null;
  const rates = Array.isArray(data?.rates) ? data.rates : [];

  return (
    <AccountShell
      title="Accepted rates"
      current="/account/rates"
      agency={account.agencyLabel}
    >
      <p className="account-lede">
        Retail prices are GST-inclusive AUD. Provider cost and margin stay
        private — you only accept the published card before billable AI use.
      </p>
      {!res.ok ? (
        <p className="account-banner">Could not load rates ({res.status}).</p>
      ) : rates.length === 0 ? (
        <p className="account-empty">No published rate card yet.</p>
      ) : (
        <ul style={{ listStyle: "none", padding: 0, display: "grid", gap: 16 }}>
          {rates.map((entry: { digest?: string; card?: Record<string, unknown> }) => {
            const card = entry.card || {};
            return (
              <li key={String(card.version || entry.digest)} className="account-stat">
                <strong style={{ fontSize: 22 }}>{String(card.version)}</strong>
                <p style={{ color: "var(--muted)", marginTop: 8 }}>
                  Currency {String(card.currency || "AUD")} · GST inclusive{" "}
                  {card.gstInclusive ? "yes" : "no"}
                </p>
                {account.role === "billing_owner" && entry.digest ? (
                  <AcceptRatesForm
                    version={String(card.version)}
                    digest={String(entry.digest)}
                  />
                ) : null}
              </li>
            );
          })}
        </ul>
      )}
    </AccountShell>
  );
}
