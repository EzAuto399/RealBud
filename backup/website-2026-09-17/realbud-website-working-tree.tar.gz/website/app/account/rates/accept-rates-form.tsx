"use client";

import { useState } from "react";

export function AcceptRatesForm({
  version,
  digest,
}: {
  version: string;
  digest: string;
}) {
  const [status, setStatus] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  return (
    <form
      className="account-actions"
      onSubmit={async (e) => {
        e.preventDefault();
        setBusy(true);
        setStatus(null);
        try {
          const res = await fetch("/api/account/rates", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ version, digest }),
          });
          setStatus(res.ok ? "Accepted for this account." : `Failed (${res.status}).`);
        } catch {
          setStatus("Network error.");
        } finally {
          setBusy(false);
        }
      }}
    >
      <button className="button button-small" type="submit" disabled={busy}>
        Accept this rate card
      </button>
      {status ? <span style={{ color: "var(--muted)" }}>{status}</span> : null}
    </form>
  );
}
