import { SUPPORT_EMAIL } from "../../lib/site";
import { AccountShell } from "./account-shell";

const titles = {
  "/account": "Account",
  "/account/usage": "Usage",
  "/account/rates": "Rates",
  "/account/invoices": "Invoices",
  "/account/limits": "Limits",
  "/account/support": "Support",
} as const;

export function AccountUnconfigured({
  current,
}: {
  current: keyof typeof titles;
}) {
  return (
    <AccountShell title={titles[current]} current={current}>
      <div className="ops-split">
        <p className="account-banner">
          Billing sign-in is not on this deployment yet. The office walkthrough
          is on <a href="/start">/start</a>. Email{" "}
          <a href={`mailto:${SUPPORT_EMAIL}`}>{SUPPORT_EMAIL}</a> if you were
          invited.
        </p>
        <aside className="ops-aside">
          <p>This login is invite-only. Do not self-serve a signup.</p>
          <a className="button" href="/start">
            Open setup
          </a>
        </aside>
      </div>
    </AccountShell>
  );
}

export { authConfigured } from "../../lib/session";
