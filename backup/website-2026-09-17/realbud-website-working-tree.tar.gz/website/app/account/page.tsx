import { redirect } from "next/navigation";
import { lookupBillingAccountByEmail } from "../../lib/billing-accounts";
import { gatewayFetch } from "../../lib/gateway";
import { SUPPORT_EMAIL } from "../../lib/site";
import { authConfigured, getSession } from "../../lib/portal-auth";
import { AccountShell } from "./account-shell";
import { AccountUnconfigured } from "./unconfigured";

export const metadata = {
  alternates: { canonical: "/account" },
  title: "Account | RealBud",
  robots: { index: false, follow: false },
};

function formatAudFromNano(nano: string | number | undefined): string {
  if (nano === undefined || nano === null) return "—";
  const n = BigInt(String(nano));
  const dollars = Number(n) / 1e9;
  return dollars.toLocaleString("en-AU", {
    style: "currency",
    currency: "AUD",
  });
}

export default async function AccountPage() {
  if (!authConfigured()) {
    return <AccountUnconfigured current="/account" />;
  }
  const session = await getSession();
  if (!session) redirect("/sign-in");
  const account = await lookupBillingAccountByEmail(session.email);
  if (!account) {
    return (
      <AccountShell title="Account" current="/account">
        <p className="account-banner">
          Your sign-in works, but this email is not provisioned for billing yet.
          RealBud accounts are invite-only. Contact{" "}
          <a href={`mailto:${SUPPORT_EMAIL}`}>{SUPPORT_EMAIL}</a> with your
          agency name.
        </p>
      </AccountShell>
    );
  }

  let usage: {
    monthlyCapNanoAud?: string;
    committedRetailNanoAud?: string;
    includedUntil?: number;
    requests?: unknown[];
  } | null = null;
  let error: string | null = null;
  try {
    const res = await gatewayFetch("/v1/portal/usage", account);
    if (res.ok) usage = await res.json();
    else error = `Gateway returned ${res.status}`;
  } catch {
    error = "Could not reach the billing gateway.";
  }

  const spent = formatAudFromNano(usage?.committedRetailNanoAud ?? "0");
  const cap = formatAudFromNano(usage?.monthlyCapNanoAud);
  const included =
    usage?.includedUntil && usage.includedUntil > Date.now()
      ? new Date(usage.includedUntil).toLocaleDateString("en-AU", {
          timeZone: "Australia/Brisbane",
        })
      : null;

  return (
    <AccountShell
      title="This month"
      current="/account"
      agency={account.agencyLabel}
    >
      {error ? <p className="account-banner">{error}</p> : null}
      <div className="account-grid">
        <div className="account-stat">
          <span>AI usage this month</span>
          <strong>{spent}</strong>
        </div>
        <div className="account-stat">
          <span>Monthly spending limit</span>
          <strong>{cap}</strong>
        </div>
        <div className="account-stat">
          <span>Care fee</span>
          <strong>A$125.00</strong>
          <p style={{ marginTop: 8, color: "var(--muted)", fontSize: 14 }}>
            GST-inclusive care, shown separately from AI usage on invoices.
          </p>
        </div>
        <div className="account-stat">
          <span>Included AI period</span>
          <strong>{included ? `Until ${included}` : "Billable"}</strong>
        </div>
      </div>
      <div className="account-actions">
        <a className="button" href="/account/invoices">
          Invoices
        </a>
        <a className="button button-secondary" href="/download">
          Download RealBud
        </a>
      </div>
    </AccountShell>
  );
}
