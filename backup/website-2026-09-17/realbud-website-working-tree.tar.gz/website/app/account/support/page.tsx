import { redirect } from "next/navigation";
import { lookupBillingAccountByEmail } from "../../../lib/billing-accounts";
import { authConfigured, getSession } from "../../../lib/portal-auth";
import { SUPPORT_EMAIL } from "../../../lib/site";
import { AccountShell } from "../account-shell";
import { AccountUnconfigured } from "../unconfigured";

export const metadata = {
  alternates: { canonical: "/account/support" },
  title: "Support | RealBud",
  robots: { index: false, follow: false },
};

export default async function SupportPage() {
  if (!authConfigured()) return <AccountUnconfigured current="/account/support" />;
  const session = await getSession();
  if (!session) redirect("/sign-in");
  const account = await lookupBillingAccountByEmail(session.email);
  if (!account) {
    return (
      <AccountShell title="Support" current="/account/support">
        <p className="account-banner">
          Not provisioned. Email{" "}
          <a href={`mailto:${SUPPORT_EMAIL}`}>{SUPPORT_EMAIL}</a>.
        </p>
      </AccountShell>
    );
  }
  return (
    <AccountShell title="Support" current="/account/support">
      <p className="account-lede">
        Billing, stop, correction or removal:{" "}
        <a href={`mailto:${SUPPORT_EMAIL}`}>{SUPPORT_EMAIL}</a>. Desktop install
        is on <a href="/download">/download</a>. Privacy for the enquiry form is
        on <a href="/privacy">/privacy</a>.
      </p>
      <h2>Pay and invoices</h2>
      <ul style={{ color: "var(--muted)", lineHeight: 1.7 }}>
        <li>
          Supplier: Yo-Da Lai, sole trader, ABN 84 992 526 369 (GST registered).
        </li>
        <li>
          Care: A$125 / month including GST when that month’s agreement
          reference is on the invoice.
        </li>
        <li>
          AI: accepted retail rates × metered units. Charge on Usage is
          GST-inclusive AUD after those rates — not OpenAI’s USD spend.
        </li>
        <li>
          Pay with Square on Invoices. Card details stay with Square. A tax
          invoice shows supplier ABN, GST-inclusive totals and GST amount.
        </li>
      </ul>
      <h2>Stop, export, delete</h2>
      <ul style={{ color: "var(--muted)", lineHeight: 1.7 }}>
        <li>
          Email {SUPPORT_EMAIL} from the provisioned work address to pause
          billable AI, close the last month, or disable the billing login.
        </li>
        <li>
          We can export your usage and invoices for that account, or remove
          billing contact records after any unpaid tax invoice is settled or
          written off.
        </li>
        <li>
          Portal login never grants office computer control and is not the
          desktop product.
        </li>
      </ul>
      <h2>What this portal is not</h2>
      <ul style={{ color: "var(--muted)", lineHeight: 1.7 }}>
        <li>
          Not consumer checkout on the marketing site. Accounts are invite-only
          for an agreed property-management office.
        </li>
        <li>
          Do not upload tenant files, passwords, or trust/notice documents here.
        </li>
        <li>
          Prices shown include GST. We do not publish wholesale cost or our
          margin on this site.
        </li>
      </ul>
    </AccountShell>
  );
}
