import Image from "next/image";
import Link from "next/link";
import { SUPPORT_EMAIL } from "../../lib/site";
import { SignOutButton } from "./sign-out-button";

const links = [
  { href: "/account", label: "Overview" },
  { href: "/account/usage", label: "Usage" },
  { href: "/account/rates", label: "Rates" },
  { href: "/account/invoices", label: "Invoices" },
  { href: "/account/limits", label: "Limits" },
  { href: "/account/support", label: "Support" },
  { href: "/start", label: "Setup" },
  { href: "/download", label: "Download" },
] as const;

export function AccountShell({
  children,
  title,
  current,
  agency,
}: {
  children: React.ReactNode;
  title: string;
  current: (typeof links)[number]["href"];
  agency?: string;
}) {
  return (
    <div className="desk">
      <header className="site-header shell">
        <Link className="brand" href="/" aria-label="RealBud home">
          <Image src="/realbud-mark.svg" width={35} height={35} alt="" priority />
          RealBud<span>Account</span>
        </Link>
        <nav aria-label="Account actions" style={{ display: "flex", gap: 16, alignItems: "center" }}>
          <a href={`mailto:${SUPPORT_EMAIL}`}>Support</a>
          <SignOutButton />
        </nav>
      </header>
      <main id="main" className="shell account-page">
        <p className="eyebrow">{agency || "Billing account"}</p>
        <h1>{title}</h1>
        <nav className="account-nav" aria-label="Account sections">
          {links.map((link) => (
            <Link
              key={link.href}
              href={link.href}
              aria-current={current === link.href ? "page" : undefined}
            >
              {link.label}
            </Link>
          ))}
        </nav>
        {children}
      </main>
    </div>
  );
}
