"use client";

import { useState } from "react";

function dollarsToNano(value: string): string {
  const n = Number(value);
  if (!Number.isFinite(n) || n < 0) throw new Error("invalid");
  return String(Math.round(n * 1e9));
}

export function LimitsForm({
  monthlyCapNanoAud,
  requestCapNanoAud,
  maxConcurrent,
}: {
  monthlyCapNanoAud: string;
  requestCapNanoAud: string;
  maxConcurrent: number;
}) {
  const [monthly, setMonthly] = useState(
    (Number(monthlyCapNanoAud) / 1e9).toFixed(2),
  );
  const [perRequest, setPerRequest] = useState(
    (Number(requestCapNanoAud) / 1e9).toFixed(2),
  );
  const [concurrent, setConcurrent] = useState(String(maxConcurrent));
  const [status, setStatus] = useState<string | null>(null);

  return (
    <form
      className="account-stat"
      style={{ display: "grid", gap: 16, maxWidth: 420 }}
      onSubmit={async (e) => {
        e.preventDefault();
        setStatus(null);
        try {
          const body = {
            monthlyCapNanoAud: dollarsToNano(monthly),
            requestCapNanoAud: dollarsToNano(perRequest),
            maxConcurrent: Number(concurrent),
          };
          const res = await fetch("/api/account/limits", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(body),
          });
          setStatus(res.ok ? "Limits updated." : `Failed (${res.status}).`);
        } catch {
          setStatus("Check the amounts and try again.");
        }
      }}
    >
      <label>
        Monthly cap (AUD incl. GST)
        <input
          value={monthly}
          onChange={(e) => setMonthly(e.target.value)}
          inputMode="decimal"
          required
        />
      </label>
      <label>
        Per-request cap (AUD)
        <input
          value={perRequest}
          onChange={(e) => setPerRequest(e.target.value)}
          inputMode="decimal"
          required
        />
      </label>
      <label>
        Max concurrent model calls
        <input
          value={concurrent}
          onChange={(e) => setConcurrent(e.target.value)}
          inputMode="numeric"
          required
        />
      </label>
      <button className="button" type="submit">
        Save limits
      </button>
      {status ? <p style={{ color: "var(--muted)" }}>{status}</p> : null}
    </form>
  );
}
