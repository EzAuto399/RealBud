import { redirect } from "next/navigation";
import { lookupBillingAccountByEmail } from "../../../lib/billing-accounts";
import { gatewayFetch } from "../../../lib/gateway";
import { SUPPORT_EMAIL } from "../../../lib/site";
import { authConfigured, getSession } from "../../../lib/portal-auth";
import { AccountShell } from "../account-shell";
import { LimitsForm } from "./limits-form";
import { AccountUnconfigured } from "../unconfigured";

export const metadata = {
  alternates: { canonical: "/account/limits" },
  title: "Limits | RealBud",
  robots: { index: false, follow: false },
};

export default async function LimitsPage() {
  if (!authConfigured()) return <AccountUnconfigured current="/account/limits" />;
  const session = await getSession();
  if (!session) redirect("/sign-in");
  const account = await lookupBillingAccountByEmail(session.email);
  if (!account) {
    return (
      <AccountShell title="Limits" current="/account/limits">
        <p className="account-banner">
          Not provisioned. Email{" "}
          <a href={`mailto:${SUPPORT_EMAIL}`}>{SUPPORT_EMAIL}</a>.
        </p>
      </AccountShell>
    );
  }
  const res = await gatewayFetch("/v1/portal/usage", account);
  const usage = res.ok
    ? ((await res.json()) as {
        monthlyCapNanoAud?: string;
        requestCapNanoAud?: string;
        maxConcurrent?: number;
      })
    : null;

  return (
    <AccountShell
      title="Spending limits"
      current="/account/limits"
      agency={account.agencyLabel}
    >
      <p className="account-lede">
        Caps are enforced on the managed gateway before provider calls. Only a
        billing owner can change them.
      </p>
      {account.role !== "billing_owner" ? (
        <p className="account-banner">Read-only access on this account.</p>
      ) : (
        <LimitsForm
          monthlyCapNanoAud={String(usage?.monthlyCapNanoAud ?? "0")}
          requestCapNanoAud={String(usage?.requestCapNanoAud ?? "0")}
          maxConcurrent={Number(usage?.maxConcurrent ?? 2)}
        />
      )}
    </AccountShell>
  );
}
