"use client";

import { useState } from "react";

export function InvoiceActions({
  id,
  canPay,
  paid,
}: {
  id: string;
  canPay: boolean;
  paid: boolean;
}) {
  const [message, setMessage] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  return (
    <div style={{ display: "flex", flexWrap: "wrap", gap: 10, alignItems: "center" }}>
      <a className="button button-secondary" href={`/api/account/invoices/${id}?kind=document`} target="_blank" rel="noreferrer">
        Tax invoice
      </a>
      {paid ? (
        <a className="button button-secondary" href={`/api/account/invoices/${id}?kind=receipt`}>
          Receipt
        </a>
      ) : canPay ? (
        <button
          type="button"
          className="button"
          disabled={busy}
          onClick={async () => {
            setMessage(null);
            setBusy(true);
            try {
              const res = await fetch(`/api/account/invoices/${id}`, { method: "POST" });
              if (!res.ok) {
                setMessage(`Checkout failed (${res.status})`);
                return;
              }
              const data = (await res.json()) as { url?: string };
              if (data.url) window.location.href = data.url;
              else setMessage("No checkout URL returned.");
            } catch {
              setMessage("Checkout could not start.");
            } finally {
              setBusy(false);
            }
          }}
        >
          {busy ? "Opening Square…" : "Pay with Square"}
        </button>
      ) : null}
      {message ? <span style={{ color: "var(--error)", fontSize: 14 }}>{message}</span> : null}
    </div>
  );
}
