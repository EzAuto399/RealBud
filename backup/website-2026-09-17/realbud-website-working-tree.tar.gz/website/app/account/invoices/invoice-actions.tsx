"use client";

import { useState } from "react";

export function InvoiceActions({
  id,
  canPay,
  paid,
}: {
  id: string;
  canPay: boolean;
  paid: boolean;
}) {
  const [message, setMessage] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  return (
    <div style={{ display: "flex", flexWrap: "wrap", gap: 10, alignItems: "center" }}>
      <a className="button button-secondary" href={`/api/account/invoices/${id}?kind=document`} target="_blank" rel="noreferrer">
        Tax invoice
      </a>
      {paid ? (
        <a className="button button-secondary" href={`/api/account/invoices/${id}?kind=receipt`}>
          Receipt
        </a>
      ) : canPay ? (
        <button
          type="button"
          className="button"
          disabled={busy}
          onClick={async () => {
            setMessage(null);
            setBusy(true);
            try {
              const res = await fetch(`/api/account/invoices/${id}`, { method: "POST" });
              if (!res.ok) {
                setMessage(`Checkout failed (${res.status})`);
                return;
              }
              const data = (await res.json()) as { url?: string };
              if (!data.url) {
                setMessage("No checkout URL returned.");
                return;
              }
              // Never hand the browser a URL that cannot take money. The gateway's
              // local simulator answers https://checkout.invalid/... (see
              // managed-gateway/local-payment.ts), which is https and would
              // otherwise pass a bare protocol check and navigate the billing owner
              // to a dead page labelled "Pay with Square".
              let checkout: URL;
              try {
                checkout = new URL(data.url);
              } catch {
                setMessage("Checkout returned an unusable link. Email hello@realbud.app.");
                return;
              }
              if (checkout.protocol !== "https:" || checkout.hostname === "checkout.invalid") {
                setMessage("Payment is not available yet. Email hello@realbud.app.");
                return;
              }
              window.location.href = checkout.toString();
            } catch {
              setMessage("Checkout could not start.");
            } finally {
              setBusy(false);
            }
          }}
        >
          {busy ? "Opening Square…" : "Pay with Square"}
        </button>
      ) : null}
      {message ? <span style={{ color: "var(--error)", fontSize: 14 }}>{message}</span> : null}
    </div>
  );
}
