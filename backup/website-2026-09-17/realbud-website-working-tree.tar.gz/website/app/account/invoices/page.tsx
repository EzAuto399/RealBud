import { redirect } from "next/navigation";
import { lookupBillingAccountByEmail } from "../../../lib/billing-accounts";
import { gatewayFetch } from "../../../lib/gateway";
import { formatAudFromCents } from "../../../lib/money";
import { SUPPORT_EMAIL } from "../../../lib/site";
import { authConfigured, getSession } from "../../../lib/portal-auth";
import { AccountShell } from "../account-shell";
import { InvoiceActions } from "./invoice-actions";
import { AccountUnconfigured } from "../unconfigured";

export const metadata = {
  alternates: { canonical: "/account/invoices" },
  title: "Invoices | RealBud",
  robots: { index: false, follow: false },
};

export default async function InvoicesPage() {
  if (!authConfigured()) return <AccountUnconfigured current="/account/invoices" />;
  const session = await getSession();
  if (!session) redirect("/sign-in");
  const account = await lookupBillingAccountByEmail(session.email);
  if (!account) {
    return (
      <AccountShell title="Invoices" current="/account/invoices">
        <p className="account-banner">
          Not provisioned. Email{" "}
          <a href={`mailto:${SUPPORT_EMAIL}`}>{SUPPORT_EMAIL}</a>.
        </p>
      </AccountShell>
    );
  }
  const res = await gatewayFetch("/v1/portal/invoices", account);
  const data = res.ok
    ? ((await res.json()) as { invoices?: Record<string, unknown>[] })
    : null;
  const invoices = Array.isArray(data?.invoices) ? data.invoices : [];

  return (
    <AccountShell
      title="Invoices"
      current="/account/invoices"
      agency={account.agencyLabel}
    >
      <p className="account-lede">
        Tax invoices are issued by Yo-Da Lai (ABN 84 992 526 369, GST
        registered). Totals are AUD including GST. Square hosts card entry — we
        do not store your card. Pay opens Square checkout for the billing owner
        only.
      </p>
      {!res.ok ? (
        <p className="account-banner">Could not load invoices ({res.status}).</p>
      ) : invoices.length === 0 ? (
        <p className="account-empty">No invoices yet.</p>
      ) : (
        <table className="account-table">
          <thead>
            <tr>
              <th>Invoice</th>
              <th>Period</th>
              <th>Total (incl. GST)</th>
              <th>GST</th>
              <th>Status</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {invoices.map((inv: Record<string, unknown>) => {
              const paid = inv.paid === true;
              return (
                <tr key={String(inv.id)}>
                  <td>{String(inv.id)}</td>
                  <td>{String(inv.period ?? "—")}</td>
                  <td>{formatAudFromCents(inv.totalCents as string | number | undefined)}</td>
                  <td>{formatAudFromCents(inv.gstCents as string | number | undefined)}</td>
                  <td>{paid ? "Paid" : "Unpaid"}</td>
                  <td>
                    <InvoiceActions
                      id={String(inv.id)}
                      canPay={account.role === "billing_owner" && !paid}
                      paid={paid}
                    />
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      )}
    </AccountShell>
  );
}
