"use client";

export function SignOutButton() {
  async function onClick() {
    await fetch("/api/auth/logout", { method: "POST" });
    window.location.href = "/sign-in";
  }
  return (
    <button className="sign-out" type="button" onClick={onClick}>
      Sign out
    </button>
  );
}
