import { SiteChrome } from "../site-chrome";
import { Walkthrough } from "./walkthrough";

export const metadata = {
  title: "Start | RealBud",
  description:
    "Invite-only onboarding for an Australian property-management office: billing login, rates, desktop install, first weekday job.",
  alternates: { canonical: "/start" },
};

export default function StartPage() {
  return (
    <div className="desk">
      <SiteChrome kicker="Start" current="start" />
      <main id="main" className="walk-page">
        <section className="walk-hero shell">
          <div>
            <p className="eyebrow">For the billing owner</p>
            <h1>
              Five steps.
              <br />
              Then the weekday
              <br />
              <em>runs on the desk.</em>
            </h1>
            <p>
              This is the office setup, not a product tour. We provision the
              login. You accept rates, install RealBud, and name one job Bud
              may prepare.
            </p>
          </div>
          <aside className="walk-aside" aria-label="What this is not">
            <p>Not a public signup.</p>
            <p>Not a cloud robot that sends mail.</p>
            <p>Not an OpenAI console for the agency.</p>
          </aside>
        </section>
        <section className="shell walk-stage">
          <Walkthrough />
        </section>
      </main>
    </div>
  );
}
