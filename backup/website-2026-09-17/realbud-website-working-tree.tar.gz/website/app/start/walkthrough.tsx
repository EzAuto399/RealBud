"use client";

import Link from "next/link";
import { useState } from "react";

const steps = [
  {
    id: "invite",
    n: "01",
    title: "We invite the billing owner",
    body: "RealBud billing is not a public signup. We email a sign-in link to the work address that pays the office. Desktop login and billing login are different doors.",
    action: { href: "mailto:hello@realbud.app", label: "Email hello@realbud.app" },
  },
  {
    id: "signin",
    n: "02",
    title: "Sign in on this site",
    body: "Use the invite on realbud.app. This account sees GST-inclusive usage, rates and invoices. It never holds an OpenAI key and never drives the Mac.",
    action: { href: "/sign-in", label: "Open billing sign-in" },
  },
  {
    id: "rates",
    n: "03",
    title: "Accept the rate card",
    body: "Billable AI waits until the billing owner accepts the published AUD card. Provider cost and any RealBud margin stay off this screen.",
    action: { href: "/account/rates", label: "Review rates" },
  },
  {
    id: "download",
    n: "04",
    title: "Install the desk on the office Mac",
    body: "Download the signed build. Keep the Mac awake for scheduled weekday jobs. Bud prepares work; send, pay and notice stay with you.",
    action: { href: "/download", label: "Download RealBud" },
  },
  {
    id: "weekday",
    n: "05",
    title: "Give Bud one weekday job",
    body: "Start with arrears or the Friday owner letter. Teach the inputs and the expected result. Recheck is Allow / Deny / Edit — not a chat log.",
    action: { href: "/#pilot", label: "Describe the first job" },
  },
] as const;

export function Walkthrough() {
  const [active, setActive] = useState(0);
  const step = steps[active]!;

  return (
    <div className="walk">
      <ol className="walk-rail" aria-label="Onboarding steps">
        {steps.map((item, index) => (
          <li key={item.id} style={{ animationDelay: `${index * 70}ms` }}>
            <button
              type="button"
              className={index === active ? "is-active" : undefined}
              onClick={() => setActive(index)}
              aria-current={index === active ? "step" : undefined}
            >
              <span>{item.n}</span>
              {item.title}
            </button>
          </li>
        ))}
      </ol>
      <article className="walk-panel" aria-live="polite">
        <p className="eyebrow">Office onboarding</p>
        <h2>{step.title}</h2>
        <p>{step.body}</p>
        <div className="walk-actions">
          <Link className="button" href={step.action.href}>
            {step.action.label}
          </Link>
          {active < steps.length - 1 ? (
            <button
              type="button"
              className="button button-secondary"
              onClick={() => setActive((n) => Math.min(n + 1, steps.length - 1))}
            >
              Next step
            </button>
          ) : null}
        </div>
      </article>
    </div>
  );
}
