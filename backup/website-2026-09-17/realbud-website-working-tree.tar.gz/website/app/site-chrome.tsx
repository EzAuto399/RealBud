import Image from "next/image";
import Link from "next/link";

export function SiteChrome({
  kicker,
  current,
}: {
  kicker: string;
  current?: "start" | "account" | "download" | "admin";
}) {
  return (
    <header className="site-header shell">
      <Link className="brand" href="/" aria-label="RealBud home">
        <Image src="/realbud-mark.svg" width={35} height={35} alt="" priority />
        RealBud<span>{kicker}</span>
      </Link>
      <nav aria-label="Main navigation">
        <Link href="/start" aria-current={current === "start" ? "page" : undefined}>
          Start
        </Link>
        <Link
          href="/download"
          aria-current={current === "download" ? "page" : undefined}
        >
          Download
        </Link>
        <Link
          href="/account"
          aria-current={current === "account" ? "page" : undefined}
        >
          Account
        </Link>
        <Link className="button button-small" href="/#pilot">
          Find your first job <span aria-hidden="true">↗</span>
        </Link>
      </nav>
    </header>
  );
}
