import { NextResponse } from "next/server";
import { getSupabaseAdmin } from "../../../lib/db";
import {
  SESSION_COOKIE,
  authConfigured,
  mintSession,
  sessionCookieOptions,
} from "../../../lib/session";
import { SITE_ORIGIN } from "../../../lib/site";

export const dynamic = "force-dynamic";

function go(path: string) {
  return NextResponse.redirect(new URL(path, SITE_ORIGIN), 303);
}

export async function GET(request: Request) {
  if (!authConfigured()) return go("/sign-in");
  const url = new URL(request.url);
  const tokenHash = url.searchParams.get("token_hash") || "";
  const type = (url.searchParams.get("type") || "email") as "email" | "magiclink";
  if (!tokenHash) return go("/sign-in");
  const admin = getSupabaseAdmin();
  if (!admin) return go("/sign-in");
  const { data, error } = await admin.auth.verifyOtp({
    token_hash: tokenHash,
    type,
  });
  const email = data.user?.email?.toLowerCase();
  if (error || !email) return go("/sign-in");
  const token = await mintSession(email);
  const res = go("/account");
  res.cookies.set(
    SESSION_COOKIE,
    token,
    sessionCookieOptions(url.protocol === "https:"),
  );
  return res;
}
