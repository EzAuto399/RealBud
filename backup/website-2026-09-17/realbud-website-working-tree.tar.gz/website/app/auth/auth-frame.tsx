import Image from "next/image";
import Link from "next/link";
import { SUPPORT_EMAIL } from "../../lib/site";
import { AuthPulse } from "./auth-pulse";

export function AuthFrame({
  title,
  children,
  mode,
}: {
  title: string;
  children: React.ReactNode;
  mode: "sign-in" | "sign-up";
}) {
  return (
    <main className="auth-shell">
      <span className="auth-grain" aria-hidden="true" />
      <section className="auth-copy">
        <Link className="auth-mark" href="/" aria-label="RealBud home">
          <Image src="/realbud-mark.svg" width={28} height={28} alt="" />
          RealBud
        </Link>
        <AuthPulse
          label={
            mode === "sign-in"
              ? "Invite-only billing for the office"
              : "We send the login. Do not self-serve."
          }
        />
        <h1>{title}</h1>
        <p>
          This login is for the property manager who pays RealBud. It is not the
          desktop office, and it never controls a computer.
        </p>
        <dl className="auth-facts">
          <div>
            <dt>Who</dt>
            <dd>Billing owner at the agency</dd>
          </div>
          <div>
            <dt>Support</dt>
            <dd>
              <a href={`mailto:${SUPPORT_EMAIL}`}>{SUPPORT_EMAIL}</a>
            </dd>
          </div>
        </dl>
      </section>
      <section className="auth-panel">{children}</section>
    </main>
  );
}

export function AuthUnavailable({ reason }: { reason: string }) {
  return (
    <div className="auth-empty">
      <div className="auth-skeleton" aria-hidden="true">
        <span />
        <span />
        <span />
      </div>
      <p>{reason}</p>
      <a className="button" href={`mailto:${SUPPORT_EMAIL}`}>
        Email {SUPPORT_EMAIL}
      </a>
    </div>
  );
}
