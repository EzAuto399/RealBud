"use client";

export function AuthPulse({ label }: { label: string }) {
  return (
    <p className="auth-pulse">
      <span className="auth-pulse-dot" aria-hidden="true" />
      <span>{label}</span>
    </p>
  );
}
