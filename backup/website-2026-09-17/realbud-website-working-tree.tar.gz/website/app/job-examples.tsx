"use client";
import { useState } from "react";
const jobs = [
  {
    name: "Arrears review",
    instruction:
      "Every Monday, use my arrears report to prepare a short list of accounts that need my attention. Flag anything missing. Leave messages as drafts.",
    source: "Your agreed arrears report",
    output: "An attention list and draft follow-ups",
  },
  {
    name: "Owner updates",
    instruction:
      "Each Friday, use our maintenance report to prepare a short update for each owner. Include progress and unresolved items. Ask me to review every draft.",
    source: "Your agreed maintenance report",
    output: "Owner update drafts for your review",
  },
  {
    name: "Document checks",
    instruction:
      "Review the documents I choose and list anything missing against our checklist. Show which files you checked and ask me about anything uncertain.",
    source: "Your chosen documents and checklist",
    output: "A checked list with missing items flagged",
  },
];
export function JobExamples() {
  const [selected, setSelected] = useState(0);
  const job = jobs[selected];
  return (
    <div className="example-jobs">
      <fieldset>
        <legend>Explore an example job</legend>
        <div className="example-options">
          {jobs.map((item, index) => (
            <label key={item.name}>
              <input
                type="radio"
                name="example-job"
                checked={selected === index}
                onChange={() => setSelected(index)}
              />
              <span>{item.name}</span>
            </label>
          ))}
        </div>
      </fieldset>
      <div aria-live="polite" aria-atomic="true">
        <blockquote className="job-quote">
          <p>“{job.instruction}”</p>
          <footer>
            An illustrative instruction. Your pilot is scoped to your own
            workflow.
          </footer>
        </blockquote>
        <dl className="example-output">
          <div>
            <dt>Starts with</dt>
            <dd>{job.source}</dd>
          </div>
          <div>
            <dt>Comes back as</dt>
            <dd>{job.output}</dd>
          </div>
        </dl>
      </div>
    </div>
  );
}
