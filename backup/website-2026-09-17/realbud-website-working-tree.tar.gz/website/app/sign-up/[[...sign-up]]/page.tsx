import { SUPPORT_EMAIL } from "../../../lib/site";
import { AuthFrame, AuthUnavailable } from "../../auth/auth-frame";

export const metadata = {
  title: "Sign up | RealBud",
  robots: { index: false, follow: false },
};

export default async function SignUpPage() {
  return (
    <AuthFrame title="Wait for the invite" mode="sign-up">
      <AuthUnavailable
        reason={`Accounts are invite-only. We email a sign-in to the provisioned work address. ${SUPPORT_EMAIL}`}
      />
    </AuthFrame>
  );
}
