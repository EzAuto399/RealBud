import type { Metadata } from "next";
import { DM_Sans, Fraunces, Outfit } from "next/font/google";
import { SITE_ORIGIN } from "../lib/site";
import "./globals.css";

const sans = DM_Sans({ variable: "--font-sans", subsets: ["latin"] });
const display = Fraunces({ variable: "--font-display", subsets: ["latin"] });
const desk = Outfit({ variable: "--font-desk", subsets: ["latin"] });

const title = "RealBud | A little more room for property managers";
const description =
  "Teach Bud your recurring property-management jobs. Review the plan, set a schedule and get prepared work back for your approval. Discuss a supervised Australian pilot.";
const siteOrigin = SITE_ORIGIN;

export const metadata: Metadata = {
  metadataBase: new URL(siteOrigin),
  title,
  description,
  alternates: { canonical: "/" },
  robots: { index: true, follow: true },
  icons: {
    icon: [{ url: "/realbud-mark.svg", type: "image/svg+xml" }],
  },
  openGraph: {
    title,
    description,
    type: "website",
    locale: "en_AU",
    images: [
      {
        url: "/og.png",
        width: 1200,
        height: 630,
        alt: "RealBud checks the routine. You handle what matters.",
      },
    ],
  },
  twitter: {
    card: "summary_large_image",
    title,
    description,
    images: ["/og.png"],
  },
};

export default function RootLayout({
  children,
}: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en-AU">
      <body className={`${sans.variable} ${display.variable} ${desk.variable}`}>
        {children}
      </body>
    </html>
  );
}
