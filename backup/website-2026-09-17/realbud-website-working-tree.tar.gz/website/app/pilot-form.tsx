"use client";

import { useRef, useState } from "react";
import type { FormEvent } from "react";
import type { FieldErrors } from "../lib/enquiries";

export function PilotForm() {
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [fields, setFields] = useState<FieldErrors>({});
  const [receipt, setReceipt] = useState("");
  const pending = useRef<{ payload: string; id: string } | null>(null);
  const submitting = useRef(false);
  const successHeading = useRef<HTMLHeadingElement>(null);

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (submitting.current) return;
    const form = event.currentTarget;
    const data = new FormData(form);
    const values = Object.fromEntries(
      ["name", "agency", "email", "workflow", "website"].map((key) => [
        key,
        String(data.get(key) ?? ""),
      ]),
    );
    const source =
      new URLSearchParams(window.location.search).get("utm_source") ?? "";
    const payload = JSON.stringify({ ...values, source });
    if (!pending.current || pending.current.payload !== payload)
      pending.current = { payload, id: crypto.randomUUID() };
    submitting.current = true;
    setBusy(true);
    setError("");
    setFields({});
    const controller = new AbortController();
    const timeout = window.setTimeout(() => controller.abort(), 20_000);
    try {
      const response = await fetch("/api/pilot", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({
          ...values,
          source,
          id: pending.current.id,
          consent: true,
        }),
        signal: controller.signal,
      });
      const raw = await response.json();
      const result =
        raw && typeof raw === "object" ? (raw as Record<string, unknown>) : {};
      if (
        !response.ok ||
        result.ok !== true ||
        result.receipt !== pending.current.id
      ) {
        setError(
          typeof result.error === "string"
            ? result.error
            : "We could not confirm your receipt. Please try again.",
        );
        if (result.fields && typeof result.fields === "object") {
          const checked = Object.fromEntries(
            Object.entries(result.fields).filter(
              ([key, value]) =>
                ["name", "agency", "email", "workflow"].includes(key) &&
                typeof value === "string",
            ),
          ) as FieldErrors;
          setFields(checked);
          const first = Object.keys(checked)[0];
          const input = first ? form.elements.namedItem(first) : null;
          if (input instanceof HTMLElement) input.focus();
        }
        return;
      }
      setReceipt(pending.current.id);
      requestAnimationFrame(() => successHeading.current?.focus());
    } catch {
      setError(
        "We could not confirm your receipt. Keep this page open and try again when your connection returns. Retrying will not save the same enquiry twice.",
      );
    } finally {
      window.clearTimeout(timeout);
      submitting.current = false;
      setBusy(false);
    }
  }

  if (receipt)
    return (
      <div className="form-success" role="status">
        <h3 tabIndex={-1} ref={successHeading}>
          Your enquiry is saved.
        </h3>
        <p>
          Thank you. We’ll review your workflow and use the work email you
          provided to discuss the fit.
        </p>
        <p>No payment has been taken and no subscription has started.</p>
        <p className="receipt">Your reference: {receipt}</p>
      </div>
    );
  const fieldError = (name: keyof FieldErrors) =>
    fields[name] ? (
      <span id={`${name}-error`} className="field-error">
        {fields[name]}
      </span>
    ) : null;
  return (
    <form className="pilot-form" onSubmit={submit} aria-busy={busy}>
      <div className="form-row">
        <div className="field">
          <label htmlFor="name">Your name</label>
          <input
            id="name"
            name="name"
            autoComplete="name"
            required
            minLength={2}
            maxLength={100}
            aria-invalid={!!fields.name}
            aria-describedby={fields.name ? "name-error" : undefined}
          />
          {fieldError("name")}
        </div>
        <div className="field">
          <label htmlFor="agency">Agency</label>
          <input
            id="agency"
            name="agency"
            autoComplete="organization"
            required
            minLength={2}
            maxLength={160}
            aria-invalid={!!fields.agency}
            aria-describedby={fields.agency ? "agency-error" : undefined}
          />
          {fieldError("agency")}
        </div>
      </div>
      <div className="field">
        <label htmlFor="email">Work email</label>
        <input
          id="email"
          name="email"
          type="email"
          autoComplete="email"
          required
          maxLength={254}
          aria-invalid={!!fields.email}
          aria-describedby={fields.email ? "email-error" : undefined}
        />
        {fieldError("email")}
      </div>
      <div className="field">
        <label htmlFor="workflow">The recurring job you’d like help with</label>
        <textarea
          id="workflow"
          name="workflow"
          required
          minLength={10}
          maxLength={2000}
          rows={4}
          placeholder="For example: preparing my weekly owner updates from our maintenance report."
          aria-invalid={!!fields.workflow}
          aria-describedby={fields.workflow ? "workflow-error" : undefined}
        />
        {fieldError("workflow")}
      </div>
      <div className="honeypot" aria-hidden="true">
        <label htmlFor="website">Leave this field empty</label>
        <input id="website" name="website" tabIndex={-1} autoComplete="off" />
      </div>
      <p className="form-caption">
        By submitting, you’re asking us to contact you about this enquiry.
        Please leave out tenant information.{" "}
        <a href="/privacy">How we use these details</a>.
      </p>
      {error && (
        <p className="form-error" role="alert">
          {error}
        </p>
      )}
      <button className="button" type="submit" disabled={busy}>
        {busy ? "Saving your enquiry…" : "Discuss my first job"}
        {!busy && <span aria-hidden="true">↗</span>}
      </button>
      <noscript>
        <p className="form-error">
          Enable JavaScript to submit this form securely and receive a saved
          reference.
        </p>
      </noscript>
    </form>
  );
}
