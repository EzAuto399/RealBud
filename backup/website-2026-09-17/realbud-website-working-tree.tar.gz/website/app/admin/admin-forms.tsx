"use client";

import { useState } from "react";

type Status = "idle" | "loading" | "error" | "ok";

function Field({
  id,
  label,
  hint,
  error,
  children,
}: {
  id: string;
  label: string;
  hint?: string;
  error?: string;
  children: React.ReactNode;
}) {
  return (
    <div className="ops-field">
      <label htmlFor={id}>{label}</label>
      {children}
      {hint ? <p className="ops-hint">{hint}</p> : null}
      {error ? (
        <p className="ops-error" role="alert">
          {error}
        </p>
      ) : null}
    </div>
  );
}

export function OfficeForm({ live }: { live: boolean }) {
  const [status, setStatus] = useState<Status>("idle");
  const [message, setMessage] = useState("");

  async function onSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!live) {
      setStatus("error");
      setMessage("Operator login is not live on this deployment.");
      return;
    }
    setStatus("loading");
    setMessage("");
    const form = new FormData(event.currentTarget);
    const res = await fetch("/api/admin/offices", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        companyId: String(form.get("companyId") || ""),
        email: String(form.get("email") || ""),
        agencyLabel: String(form.get("agencyLabel") || ""),
        role: String(form.get("role") || "billing_owner"),
      }),
    });
    const data = (await res.json().catch(() => ({}))) as { error?: string };
    if (!res.ok) {
      setStatus("error");
      setMessage(data.error || "Could not provision this office.");
      return;
    }
    setStatus("ok");
    setMessage("Office row saved. Map the OpenAI key_… on the gateway next.");
  }

  return (
    <form className="ops-form" onSubmit={onSubmit}>
      <Field
        id="agencyLabel"
        label="Agency"
        hint="The name the billing owner sees."
      >
        <input id="agencyLabel" name="agencyLabel" required minLength={2} />
      </Field>
      <Field
        id="email"
        label="Billing owner email"
        hint="Work address we will email a sign-in link to."
      >
        <input id="email" name="email" type="email" required />
      </Field>
      <Field
        id="companyId"
        label="Company id"
        hint="Must match the gateway tenant and the OpenAI key mapping."
      >
        <input id="companyId" name="companyId" required minLength={3} />
      </Field>
      <Field id="role" label="Role">
        <select id="role" name="role" defaultValue="billing_owner">
          <option value="billing_owner">Billing owner</option>
          <option value="billing_reader">Billing reader</option>
        </select>
      </Field>
      {status === "error" ? (
        <p className="ops-error" role="alert">
          {message}
        </p>
      ) : null}
      {status === "ok" ? <p className="ops-ok">{message}</p> : null}
      <button className="button" type="submit" disabled={status === "loading"}>
        {status === "loading" ? "Saving" : "Provision office"}
      </button>
    </form>
  );
}

export function MarginForm({ live }: { live: boolean }) {
  const [apply, setApply] = useState(true);
  const [status, setStatus] = useState<Status>("idle");
  const [message, setMessage] = useState("");

  async function onSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!live) {
      setStatus("error");
      setMessage("Margin is recorded on the gateway. This desk is not wired yet.");
      return;
    }
    setStatus("loading");
    const form = new FormData(event.currentTarget);
    const res = await fetch("/api/admin/margin", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        companyId: String(form.get("companyId") || ""),
        version: String(form.get("version") || ""),
        apply: form.get("apply") === "on",
        method: String(form.get("method") || "margin"),
        basisPoints: Number(form.get("basisPoints") || 0),
      }),
    });
    const data = (await res.json().catch(() => ({}))) as { error?: string };
    if (!res.ok) {
      setStatus("error");
      setMessage(data.error || "Could not record margin policy.");
      return;
    }
    setStatus("ok");
    setMessage("Policy version recorded. Clients still see GST-inc Charge only.");
  }

  return (
    <form className="ops-form" onSubmit={onSubmit}>
      <Field id="margin-company" label="Company id">
        <input id="margin-company" name="companyId" required minLength={3} />
      </Field>
      <Field
        id="version"
        label="Policy version"
        hint="Immutable. Use a new version to change or turn off."
      >
        <input id="version" name="version" required minLength={3} />
      </Field>
      <label className="ops-check">
        <input
          type="checkbox"
          name="apply"
          checked={apply}
          onChange={(event) => setApply(event.target.checked)}
        />
        Apply extra margin
      </label>
      <p className="ops-hint">
        Off = FX + 10% GST only. On = stored percentage. Never shown on
        /account.
      </p>
      <Field id="method" label="Method">
        <select id="method" name="method" defaultValue="margin" disabled={!apply}>
          <option value="margin">Margin (cost / (1 - %))</option>
          <option value="markup">Markup (cost × (1 + %))</option>
        </select>
      </Field>
      <Field
        id="basisPoints"
        label="Basis points"
        hint="2500 = 25%. Ignored when Apply is off."
      >
        <input
          id="basisPoints"
          name="basisPoints"
          type="number"
          min={0}
          max={9999}
          step={50}
          defaultValue={2000}
          disabled={!apply}
        />
      </Field>
      {status === "error" ? (
        <p className="ops-error" role="alert">
          {message}
        </p>
      ) : null}
      {status === "ok" ? <p className="ops-ok">{message}</p> : null}
      <button className="button" type="submit" disabled={status === "loading"}>
        {status === "loading" ? "Recording" : "Record policy"}
      </button>
    </form>
  );
}
