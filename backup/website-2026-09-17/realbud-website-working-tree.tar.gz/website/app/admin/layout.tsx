import { notFound } from "next/navigation";
import { isOperatorEmail } from "../../lib/operator";
import { authConfigured, getSession } from "../../lib/portal-auth";

export default async function AdminLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  if (!authConfigured()) notFound();
  const session = await getSession();
  if (!session || !isOperatorEmail(session.email)) notFound();
  return children;
}
