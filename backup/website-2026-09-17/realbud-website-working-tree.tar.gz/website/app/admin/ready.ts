import { supabaseConfigured } from "../../lib/db";
import { authConfigured } from "../../lib/session";

export function operatorReady(): boolean {
  return Boolean(
    authConfigured() &&
      process.env.REALBUD_OPERATOR_EMAILS &&
      supabaseConfigured(),
  );
}
