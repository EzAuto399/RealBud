import { AdminShell } from "../admin-shell";
import { OfficeForm } from "../admin-forms";
import { operatorReady } from "../ready";

export const metadata = {
  title: "Offices | RealBud operator",
  robots: { index: false, follow: false },
};

export default function AdminOfficesPage() {
  const live = operatorReady();
  return (
    <AdminShell title="Offices" current="/admin/offices" live={live}>
      <div className="ops-split">
        <section>
          <h2>Provision</h2>
          <OfficeForm live={live} />
        </section>
        <aside className="ops-aside">
          <p className="account-empty">
            No office list is loaded on this host yet. After D1 or a RealBud
            database exists, this column becomes the live book.
          </p>
        </aside>
      </div>
    </AdminShell>
  );
}
