import Image from "next/image";
import Link from "next/link";

const links = [
  { href: "/admin", label: "Desk" },
  { href: "/admin/offices", label: "Offices" },
  { href: "/admin/margin", label: "Margin" },
] as const;

export function AdminShell({
  children,
  title,
  current,
  live,
}: {
  children: React.ReactNode;
  title: string;
  current: (typeof links)[number]["href"];
  live: boolean;
}) {
  return (
    <div className="desk">
      <header className="site-header shell">
        <Link className="brand" href="/admin" aria-label="RealBud operator desk">
          <Image src="/realbud-mark.svg" width={35} height={35} alt="" priority />
          RealBud<span>Operator</span>
        </Link>
        <nav aria-label="Operator">
          <Link href="/start">Onboarding</Link>
          <Link href="/account">Customer portal</Link>
        </nav>
      </header>
      <main id="main" className="shell ops-page">
        <p className="eyebrow">Operator only</p>
        <h1>{title}</h1>
        {!live ? (
          <p className="account-banner">
            This desk is designed and wired to fail closed. Operator email plus
            REALBUD_OPERATOR_EMAILS must be set before a row can be saved.
          </p>
        ) : null}
        <nav className="account-nav" aria-label="Operator sections">
          {links.map((link) => (
            <Link
              key={link.href}
              href={link.href}
              aria-current={current === link.href ? "page" : undefined}
            >
              {link.label}
            </Link>
          ))}
        </nav>
        {children}
      </main>
    </div>
  );
}
