import { AdminShell } from "./admin-shell";
import { operatorReady } from "./ready";

export const metadata = {
  title: "Operator | RealBud",
  robots: { index: false, follow: false },
};

export default function AdminPage() {
  const live = operatorReady();
  return (
    <AdminShell title="Operator desk" current="/admin" live={live}>
      <div className="ops-split">
        <section>
          <h2>What this desk does</h2>
          <ol className="ops-list">
            <li>Email the billing owner a sign-in link from this desk.</li>
            <li>Provision the office row (company id + work email).</li>
            <li>Create an OpenAI key in our org. Map key_… on the gateway.</li>
            <li>Record margin apply / skip as a new policy version.</li>
            <li>Month close is GST-inc Charge on their invoices.</li>
          </ol>
        </section>
        <aside className="ops-aside">
          <p>Clients never see wholesale, basis points, or Apply.</p>
          <p>Empty offices are expected until the first invite is accepted.</p>
          <a className="button" href="/admin/offices">
            Provision an office
          </a>
        </aside>
      </div>
    </AdminShell>
  );
}
