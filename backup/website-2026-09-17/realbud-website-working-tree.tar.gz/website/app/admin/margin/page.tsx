import { AdminShell } from "../admin-shell";
import { MarginForm } from "../admin-forms";
import { operatorReady } from "../ready";

export const metadata = {
  title: "Margin | RealBud operator",
  robots: { index: false, follow: false },
};

export default function AdminMarginPage() {
  const live = operatorReady();
  return (
    <AdminShell title="Margin" current="/admin/margin" live={live}>
      <div className="ops-split">
        <section>
          <h2>Apply or skip</h2>
          <p>
            Per office, versioned. Skip extra margin with Apply off. Clients
            still pay GST-inc AUD; they cannot toggle this.
          </p>
          <MarginForm live={live} />
        </section>
        <aside className="ops-aside">
          <p>2000 basis points = 20% margin.</p>
          <p>Apply off keeps the stored % for a later version.</p>
          <p>Portal tests fail if basisPoints leaks to /account.</p>
        </aside>
      </div>
    </AdminShell>
  );
}
