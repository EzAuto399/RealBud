import Image from "next/image";
import Link from "next/link";
import { GITHUB_RELEASES } from "../../lib/site";
import { latestReleaseDownloads } from "../../lib/releases";

export const metadata = {
  alternates: { canonical: "/download" },
  title: "Download RealBud",
  description:
    "Install RealBud for macOS Apple Silicon. Auto-update is built in once you install from this page.",
};

export const revalidate = 300;

export default async function DownloadPage() {
  const release = await latestReleaseDownloads();
  return (
    <>
      <header className="site-header shell">
        <Link className="brand" href="/" aria-label="RealBud home">
          <Image src="/realbud-mark.svg" width={35} height={35} alt="" priority />
          RealBud<span>Property desk</span>
        </Link>
        <nav aria-label="Main navigation">
          <Link href="/">Home</Link>
          <Link href="/account">Account</Link>
          <Link className="button button-small" href="/#pilot">
            Talk to us <span aria-hidden="true">↗</span>
          </Link>
        </nav>
      </header>
      <main id="main" className="shell download-page">
        <p className="eyebrow">Desktop app</p>
        <h1>Download RealBud.</h1>
        <p className="download-lede">
          RealBud runs on your office Mac. After install, use{" "}
          <strong>Check for updates</strong> in the sidebar — updates come from
          the same signed GitHub release feed.
        </p>

        <section className="download-cards" aria-label="Installers">
          <article className="download-card download-card-primary">
            <h2>macOS (Apple Silicon)</h2>
            <p>
              {release.mac
                ? `Version ${release.version} · notarized DMG`
                : "Latest notarized DMG when a public release is published."}
            </p>
            <a
              className="button"
              href={release.mac?.dmgUrl ?? GITHUB_RELEASES.macDmgAlias}
            >
              Download for Mac <span aria-hidden="true">↓</span>
            </a>
            {release.mac?.zipUrl ? (
              <p className="download-alt">
                <a href={release.mac.zipUrl}>Zip for auto-update</a>
                {" · "}
                <a href={GITHUB_RELEASES.latestMacYml}>latest-mac.yml</a>
              </p>
            ) : null}
          </article>

          <article className="download-card">
            <h2>Windows</h2>
            <p>
              {release.win
                ? `Version ${release.version} · unsigned installer (Authenticode pending)`
                : "Windows installer ships when a signed public build is ready. Until then, Mac is the supported pilot path."}
            </p>
            {release.win ? (
              <a className="button button-secondary" href={release.win.setupUrl}>
                Download for Windows <span aria-hidden="true">↓</span>
              </a>
            ) : (
              <p className="download-note">
                Prefer macOS for the supervised pilot. Email{" "}
                <a href="mailto:hello@realbud.app">hello@realbud.app</a> if you
                need a Windows build.
              </p>
            )}
          </article>
        </section>

        <section className="download-notes">
          <h2>Before you install</h2>
          <ul>
            <li>Apple Silicon Mac (arm64). Intel Mac is not in this release.</li>
            <li>
              Keep the computer awake when scheduled jobs run — RealBud is not an
              always-on cloud bot.
            </li>
            <li>
              Account billing and spend live at{" "}
              <Link href="/account">realbud.app/account</Link>, separate from
              the desktop office login.
            </li>
          </ul>
          {release.publishedAt ? (
            <p className="download-meta">
              Release published {new Date(release.publishedAt).toLocaleString("en-AU", {
                timeZone: "Australia/Brisbane",
              })}
              {release.htmlUrl ? (
                <>
                  {" · "}
                  <a href={release.htmlUrl}>Release notes</a>
                </>
              ) : null}
            </p>
          ) : null}
        </section>
      </main>
    </>
  );
}
