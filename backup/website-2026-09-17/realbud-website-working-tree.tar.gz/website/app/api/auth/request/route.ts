import { NextResponse } from "next/server";
import { getSupabaseAdmin } from "../../../../lib/db";
import { lookupBillingAccountByEmail } from "../../../../lib/billing-accounts";
import { isOperatorEmail } from "../../../../lib/operator";
import { authConfigured } from "../../../../lib/session";
import { SITE_ORIGIN } from "../../../../lib/site";

export const dynamic = "force-dynamic";

const SAME = { ok: true as const };

export async function POST(request: Request) {
  if (!authConfigured()) {
    return NextResponse.json(
      { error: "Sign-in is not configured." },
      { status: 503, headers: { "Cache-Control": "no-store" } },
    );
  }
  const body = (await request.json().catch(() => null)) as {
    email?: unknown;
  } | null;
  const email =
    typeof body?.email === "string" ? body.email.trim().toLowerCase() : "";
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || email.length > 254) {
    return NextResponse.json(SAME, { headers: { "Cache-Control": "no-store" } });
  }
  const invited =
    isOperatorEmail(email) || Boolean(await lookupBillingAccountByEmail(email));
  if (!invited) {
    return NextResponse.json(SAME, { headers: { "Cache-Control": "no-store" } });
  }
  const admin = getSupabaseAdmin();
  if (!admin) {
    return NextResponse.json(SAME, { headers: { "Cache-Control": "no-store" } });
  }
  const origin = SITE_ORIGIN;
  const created = await admin.auth.admin.createUser({
    email,
    email_confirm: false,
  });
  if (created.error && !/already/i.test(created.error.message)) {
    return NextResponse.json(SAME, { headers: { "Cache-Control": "no-store" } });
  }
  await admin.auth.signInWithOtp({
    email,
    options: {
      shouldCreateUser: false,
      emailRedirectTo: `${origin}/auth/callback`,
    },
  });
  return NextResponse.json(SAME, { headers: { "Cache-Control": "no-store" } });
}
