import { requireBillingAccount } from "../../../../lib/account-auth";
import { gatewayFetch } from "../../../../lib/gateway";
import { isAllowedBrowserOrigin } from "../../../../lib/site";

export async function POST(request: Request) {
  const origin = request.headers.get("origin");
  if (origin && !isAllowedBrowserOrigin(origin)) {
    return Response.json({ error: "origin_denied" }, { status: 403 });
  }
  const gate = await requireBillingAccount();
  if (gate.error) return gate.error;
  if (gate.account.role !== "billing_owner") {
    return Response.json({ error: "forbidden" }, { status: 403 });
  }
  const upstream = await gatewayFetch("/v1/portal/limits", gate.account, {
    method: "POST",
    body: await request.text(),
  });
  const body = await upstream.text();
  return new Response(body, {
    status: upstream.status,
    headers: {
      "Content-Type": "application/json; charset=utf-8",
      "Cache-Control": "no-store",
    },
  });
}
