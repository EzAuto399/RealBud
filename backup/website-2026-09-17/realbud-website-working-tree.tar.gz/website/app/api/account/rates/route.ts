import { requireBillingAccount } from "../../../../lib/account-auth";
import { gatewayFetch } from "../../../../lib/gateway";
import { isAllowedBrowserOrigin } from "../../../../lib/site";

async function proxy(
  request: Request,
  path: string,
  method: "GET" | "POST",
) {
  const origin = request.headers.get("origin");
  if (origin && !isAllowedBrowserOrigin(origin)) {
    return Response.json({ error: "origin_denied" }, { status: 403 });
  }
  const gate = await requireBillingAccount();
  if (gate.error) return gate.error;
  const init: RequestInit = { method };
  if (method === "POST") {
    init.body = await request.text();
  }
  const upstream = await gatewayFetch(path, gate.account, init);
  const body = await upstream.text();
  const type = upstream.headers.get("content-type") || "application/json";
  return new Response(body, {
    status: upstream.status,
    headers: { "Content-Type": type, "Cache-Control": "no-store" },
  });
}

export async function GET(request: Request) {
  return proxy(request, "/v1/portal/rates", "GET");
}

export async function POST(request: Request) {
  return proxy(request, "/v1/portal/rates/accept", "POST");
}
