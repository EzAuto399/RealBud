import { requireBillingAccount } from "../../../../../lib/account-auth";
import { gatewayFetch } from "../../../../../lib/gateway";
import { isAllowedBrowserOrigin } from "../../../../../lib/site";

type Params = { params: Promise<{ id: string }> };

function safeId(id: string): string | null {
  return /^[A-Za-z0-9-]{8,80}$/.test(id) ? id : null;
}

export async function GET(request: Request, ctx: Params) {
  const origin = request.headers.get("origin");
  if (origin && !isAllowedBrowserOrigin(origin)) {
    return Response.json({ error: "origin_denied" }, { status: 403 });
  }
  const { id: raw } = await ctx.params;
  const id = safeId(raw);
  if (!id) return Response.json({ error: "not_found" }, { status: 404 });
  const gate = await requireBillingAccount();
  if (gate.error) return gate.error;
  const url = new URL(request.url);
  const kind = url.searchParams.get("kind");
  const path =
    kind === "document"
      ? `/v1/portal/invoices/${id}/document`
      : kind === "receipt"
        ? `/v1/portal/invoices/${id}/receipt`
        : `/v1/portal/invoices/${id}`;
  const upstream = await gatewayFetch(path, gate.account);
  const body = await upstream.text();
  return new Response(body, {
    status: upstream.status,
    headers: {
      "Content-Type":
        upstream.headers.get("content-type") || "application/json; charset=utf-8",
      "Cache-Control": "no-store",
    },
  });
}

export async function POST(request: Request, ctx: Params) {
  const origin = request.headers.get("origin");
  if (origin && !isAllowedBrowserOrigin(origin)) {
    return Response.json({ error: "origin_denied" }, { status: 403 });
  }
  const { id: raw } = await ctx.params;
  const id = safeId(raw);
  if (!id) return Response.json({ error: "not_found" }, { status: 404 });
  const gate = await requireBillingAccount();
  if (gate.error) return gate.error;
  const upstream = await gatewayFetch(
    `/v1/portal/invoices/${id}/checkout`,
    gate.account,
    { method: "POST", body: "{}" },
  );
  const body = await upstream.text();
  return new Response(body, {
    status: upstream.status,
    headers: {
      "Content-Type": "application/json; charset=utf-8",
      "Cache-Control": "no-store",
    },
  });
}
