import { requireBillingAccount } from "../../../../lib/account-auth";
import { gatewayFetch } from "../../../../lib/gateway";
import { isAllowedBrowserOrigin } from "../../../../lib/site";

export async function GET(request: Request) {
  const origin = request.headers.get("origin");
  if (origin && !isAllowedBrowserOrigin(origin)) {
    return Response.json({ error: "origin_denied" }, { status: 403 });
  }
  const gate = await requireBillingAccount();
  if (gate.error) return gate.error;
  const upstream = await gatewayFetch("/v1/portal/usage", gate.account);
  const body = await upstream.text();
  return new Response(body, {
    status: upstream.status,
    headers: {
      "Content-Type": "application/json; charset=utf-8",
      "Cache-Control": "no-store",
    },
  });
}
