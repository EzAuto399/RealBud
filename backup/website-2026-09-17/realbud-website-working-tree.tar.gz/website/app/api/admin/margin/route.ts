import { NextResponse } from "next/server";
import { requireOperator } from "../../../../lib/portal-auth";

export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  const gate = await requireOperator();
  if (gate.error) return gate.error;
  const body = (await request.json().catch(() => null)) as {
    companyId?: string;
    version?: string;
    apply?: boolean;
    method?: string;
    basisPoints?: number;
  } | null;
  if (!body?.companyId || !body.version) {
    return NextResponse.json({ error: "Company id and version are required." }, { status: 422 });
  }
  const gateway = (process.env.REALBUD_GATEWAY_URL || "").replace(/\/$/, "");
  if (!gateway) {
    return NextResponse.json(
      { error: "Gateway is not on this deployment. Policy was not recorded." },
      { status: 503 },
    );
  }
  return NextResponse.json(
    { error: "Gateway has no public operator HTTP yet. Record the policy on the server." },
    { status: 503 },
  );
}
