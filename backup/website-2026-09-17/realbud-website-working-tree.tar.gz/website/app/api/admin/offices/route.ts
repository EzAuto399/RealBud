import { NextResponse } from "next/server";
import { requireOperator } from "../../../../lib/portal-auth";
import { provisionBillingAccount } from "../../../../lib/billing-accounts";

export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  const gate = await requireOperator();
  if (gate.error) return gate.error;
  const body = (await request.json().catch(() => null)) as {
    companyId?: string;
    email?: string;
    agencyLabel?: string;
    role?: "billing_owner" | "billing_reader";
  } | null;
  const email = body?.email?.trim().toLowerCase() || "";
  if (
    !body?.companyId ||
    !email ||
    !body.agencyLabel ||
    (body.role !== "billing_owner" && body.role !== "billing_reader")
  ) {
    return NextResponse.json({ error: "Check the highlighted fields." }, { status: 422 });
  }
  try {
    await provisionBillingAccount({
      clerkUserId: email,
      companyId: body.companyId,
      email,
      agencyLabel: body.agencyLabel,
      role: body.role,
    });
  } catch {
    return NextResponse.json(
      { error: "Database is not on this host yet. Row was not saved." },
      { status: 503 },
    );
  }
  return NextResponse.json({ ok: true });
}
