import { getEnquiryDatabase } from "../../../lib/db";
import { receiveEnquiry } from "../../../lib/enquiries";
export async function POST(request: Request) {
  return receiveEnquiry(request, getEnquiryDatabase());
}
