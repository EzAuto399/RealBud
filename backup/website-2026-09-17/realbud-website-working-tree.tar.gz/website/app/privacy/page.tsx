import Link from "next/link";
export const metadata = {
  alternates: { canonical: "/privacy" },
  title: "RealBud enquiry privacy",
  description:
    "How RealBud handles details submitted through the pilot enquiry form.",
};
export default function Privacy() {
  return (
    <main className="privacy-page shell">
      <Link className="text-link" href="/">
        ← Back to RealBud
      </Link>
      <p className="eyebrow" style={{ marginTop: 36 }}>
        Website enquiries
      </p>
      <h1>How we use your details.</h1>
      <p>
        The pilot enquiry form is operated by the RealBud team to review whether
        a recurring property-management job is a suitable pilot.
      </p>
      <h2>What the form saves</h2>
      <p>
        Your name, agency, work email, workflow description, request reference,
        submission time and campaign source if one was provided. A daily hashed
        technical identifier helps limit spam; your raw IP address is not stored
        in the enquiry record.
      </p>
      <h2>Why we save it</h2>
      <p>
        To review the request, reply to you and keep track of the discussion.
        Submitting this form does not subscribe you to marketing, create a paid
        account or start a pilot.
      </p>
      <h2>Who can access it</h2>
      <p>
        The RealBud site owner can access enquiries through the hosting
        platform’s private database tools. Enquiry records are not available
        through a public webpage or download. The website and its database use
        OpenAI Sites and Cloudflare hosting infrastructure.
      </p>
      <h2>Keep sensitive information out</h2>
      <p>
        Please do not submit tenant details, property documents, passwords,
        credentials or financial records. Any pilot’s source access and
        model-provider arrangements are agreed separately.
      </p>
      <h2>Corrections or removal</h2>
      <p>
        You can request a correction or removal by emailing{" "}
        <a href="mailto:hello@realbud.app">hello@realbud.app</a>, by replying to
        our follow-up, or using the enquiry form with “privacy request” and your
        reference. Use the same work email so we can verify the request before
        changing a record.
      </p>
      <p>
        This notice describes the website enquiry form and account portal
        contact. Invite-only billing logins store the invited work email, agency label and
        invoices; they are not mixed with office property files. Card payments,
        when enabled, are hosted by Square. It does not replace the data-handling
        agreement for an agency pilot or paid billing terms.
      </p>
      <p>Updated 16 September 2026.</p>
    </main>
  );
}
